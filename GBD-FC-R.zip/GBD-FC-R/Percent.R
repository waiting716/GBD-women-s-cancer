setwd('D:/GBD/Female-cancer/2021/data/risk') ##???ù???·??
library(ggplot2)
library(ggsci)
library(dplyr)
LC1 <- read.csv('female cancer -risk.csv',header = T)  ## ??ȡ???ǵ?????
order <- read.csv('order.csv',header = F) 
order$V1 <- rev(order$V1)

LC <- subset(LC1, rei %in% c("Dietary risks", 
                             "High alcohol use", 
                             "High body-mass index", 
                             "High fasting plasma glucose", 
                             "Low physical activity", 
                             "Occupational risks",
                             "Tobacco",
                             "Unsafe sex") &
               cause == "Ovarian cancer" &
               location != "Global") 
#####2021
case <- subset(LC, 
               year == 2021 & 
                 age == 'All ages' & 
                 metric == 'Number' &
                 measure == 'DALYs (Disability-Adjusted Life Years)')

#### ?????????ݼ?
# Create LC_percent data frame
LC_percent <- data.frame(location=rep(unique(LC$location),each=length(unique(LC$rei))),
                         rei=rep(unique(LC$rei),length(unique(LC$location))),
                         percent=rep(NA,times=length(unique(LC$rei))*length(unique(LC$location))))

a <- unique(LC$location)
b <- unique(LC$rei)
for (i in 1:length(unique(LC$location))){
  location_i <- a[i]
  data <- subset(case,case$location==location_i)[,c(2,6,9)]
  sum <- sum(data$val)
  data$percent <- data$val/sum
  data <- data[,-3]
  for (j in 1:length(unique(LC$rei))) {
    rei_j <- b[j]
    LC_percent[which(LC_percent$location==location_i & LC_percent$rei==rei_j),3] <- data$percent[which(data$rei==rei_j)]
  }
}

LC_2019 <- LC_percent
LC_2019$year <- 2021




####  1990
case <- subset(LC, 
               year == 1990 & 
                 age == 'All ages' & 
                 metric == 'Number' &
                 measure == 'DALYs (Disability-Adjusted Life Years)')

#### ?????????ݼ?
# Create LC_percent data frame
LC_percent <- data.frame(location=rep(unique(LC$location),each=length(unique(LC$rei))),
                         rei=rep(unique(LC$rei),length(unique(LC$location))),
                         percent=rep(NA,times=length(unique(LC$rei))*length(unique(LC$location))))

a <- unique(LC$location)
b <- unique(LC$rei)
for (i in 1:length(unique(LC$location))){
  location_i <- a[i]
  data <- subset(case,case$location==location_i)[,c(2,6,9)]
  sum <- sum(data$val)
  data$percent <- data$val/sum
  data <- data[,-3]
  for (j in 1:length(unique(LC$rei))) {
    rei_j <- b[j]
    LC_percent[which(LC_percent$location==location_i & LC_percent$rei==rei_j),3] <- data$percent[which(data$rei==rei_j)]
  }
}



LC_1990 <- LC_percent
LC_1990$year <- 1990

#合并
LC_1990_2019 <- rbind(LC_1990,LC_2019)
LC_1990_2019$text <- as.character(round(LC_1990_2019$percent*100,1))  ### ???ӱ?ǩ??��????????ʾ??ͼ????
#### ????ͼ?е?˳??ָ????��????˳??
LC_1990_2019$location <- factor(LC_1990_2019$location, 
                        levels=order$V1, 
                        ordered=TRUE)
LC_1990_2019$rei <- factor(LC_1990_2019$rei, 
                             levels=c("Dietary risks", 
                                      "High alcohol use", 
                                      "High body-mass index", 
                                      "High fasting plasma glucose", 
                                      "Low physical activity", 
                                      "Occupational risks",
                                      "Tobacco",
                                      "Unsafe sex"), 
                             ordered=TRUE)
### 组图
# Define custom colors
custom_colors <- c(
  "Dietary risks" = "#91D1C2",
  "High alcohol use" = "#8491B4",  # Updated color code
  "High body-mass index" = "#CC9999",
  "High fasting plasma glucose" = "#3C5488",
  "Low physical activity" = "#993333",
  "Occupational risks" = "#CCCCCC",
  "Tobacco" = "#FFCC66",
  "Unsafe sex" = "#99CC99"
)

# Create the plot



# 加载必要的库
library(dplyr)
PP1 <- ggplot(data = LC_1990_2019, aes(x = location, y = percent, fill = rei)) +
  geom_bar(stat = 'identity', position = 'fill') +
  labs(x = '', y = 'Percentage') + 
  scale_fill_manual(values = custom_colors) + 
  coord_flip() + 
  facet_grid(. ~ year) + 
  theme_light() +
  
  # 显示百分比数值，只显示大于2%的值
  geom_text(aes(label = ifelse(percent > 0.02, paste0(round(percent * 100, 1)), "")),  # 条件显示
            position = position_stack(vjust = 0.5), 
            size = 2,
            color = "black",
            hjust = 0.5) +
  
  # 设置所有文本为 Times New Roman (serif) 并加粗
  theme(text = element_text(family = "serif", face = "bold"),
        legend.position = "none")  # 不显示图例


print(PP1)
library(eoffice)
  topptx(PP1,filename = "OC-percent2.pptx",width = 10,#图形在宽度
       height = 6#图形在高度
)
