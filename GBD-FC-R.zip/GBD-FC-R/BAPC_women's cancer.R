setwd('D:/zuhui/GBD/Female-cancer/2021/data/forecast')##设置工作路径

# ###INLA
#install.packages("devtools")
devtools::install_github(repo = "https://github.com/hrue/r-inla", ref = "stable", subdir = "rinla", build = FALSE, dependencies = TRUE)

#install.packages('foreach')
install.packages("D:/组会/GBD/diet-related cancer/GBD2021/data/forecast/INLA_24.01.20.zip", repos = NULL, type = "source")

# ####BAPC
install.packages("cmprsk")
install.packages("caTools")
install.packages("fanplot")
install.packages("Epi")
install.packages("BAPC", repos = "http://R-Forge.R-project.org", type = "source")
#install.packages("foreach")
#install.packages("fmesher")
#install.packages("D:/组会/GBD/diet-related cancer/预测/prediction/R_packages/haraldwf-nordpred-ef83b2c.tar.gz")
#install.packages("D:/组会/GBD/diet-related cancer/预测/prediction/R_packages/BAPC_0.0.34.tar.gz")
#install.packages("D:/组会/GBD/diet-related cancer/预测/prediction/R_packages/Epi_2.47.1.zip")

library(foreach)
library(nordpred)
library(Matrix)
library(parallel)
library(sp)
library(INLA)
# inla.upgrade(testing=TRUE)
inla.setOption(working.directory = "D:/Ruanjian/home_directory")
library(caTools)
library(fanplot)
library(Epi)
library(colorspace)
library(BAPC)
#install.packages("reshape")
library(reshape)
library(data.table)
#install.packages("tidyr")
library(tidyr)
#install.packages("tidyverse")
library(tidyverse)
#install.packages("epitools")
library(epitools)
library(ggplot2)
library(dplyr)


rm(list = ls())

esoph <-  fread("FC.csv")  #Total <- read.csv('D:\\YanJiuSheng\\KeYan\\GBD\\Physical\\Total_PS_2019_number.csv',header = T)
esoph_FC <- subset(esoph, 
                     metric == 'Number'&
                     location== 'Global')
esoph_FC <- esoph_FC[,-c(2,3,6)]  ### 只取需要的变量：地区以及对应的数值

##处理Female cancer-----Breast cancer/cervical cancer/uterine cancer/ovarian cancer
#1Breast cancer
esoph_BC <- subset(esoph_FC, cause == 'Breast cancer')
esoph_BC <- esoph_BC[,-c(3)]  ### 只取需要的变量：地区以及对应的数值
#2Cervical cancer
esoph_CC <- subset(esoph_FC, cause == 'Cervical cancer')
esoph_CC <- esoph_CC[,-c(3)]  ### 只取需要的变量：地区以及对应的数值
#3 Uterine cancer
esoph_UC <- subset(esoph_FC, cause == 'Uterine cancer')
esoph_UC <- esoph_UC[,-c(3)]  ### 只取需要的变量：地区以及对应的数值
#4Ovarian cancer
esoph_OC <- subset(esoph_FC, cause == 'Ovarian cancer')
esoph_OC <- esoph_OC[,-c(3)]  ### 只取需要的变量：地区以及对应的数值

#Female cancer
esoph_FC1<- data.frame(measure=esoph_BC$measure,age=esoph_BC$age,cause=rep('Female cancer',times=2100),year=esoph_BC$year,val=rep(0,times=2100),upper=rep(0,times=2100),lower=rep(0,times=2100)) #创建一个数据框
for (i in 1:2100){
  measure_name <- as.character(esoph_FC1[i,1])
  age_name <- as.character(esoph_FC1[i,2])
  year_name <- as.character(esoph_FC1[i,4])
  a <- subset(esoph_FC, esoph_FC$measure==measure_name  & esoph_FC$age==age_name & esoph_FC$year==year_name)  ##取对应地区的数据子集
  val <- sum(a$val)
  upper <- sum(a$upper)
  lower <- sum(a$lower)
  esoph_FC1[i,5] <- val
  esoph_FC1[i,7] <- lower
  esoph_FC1[i,6] <- upper
}



unique(esoph$age_name)
ages <- c( "<5 years", "5-9 years","10-14 years", "15-19 years","20-24 years", "25-29 years","30-34 years", "35-39 years", 
           "40-44 years", "45-49 years", "50-54 years", "55-59 years","60-64 years", "65-69 years", "70-74 years", "75-79 years",
           "80-84 years","85-89 years","90-94 years","95+ years" )


### for Female cancer
esoph_ages_FC  <- subset(esoph_FC1,age %in% ages &
                           measure =='Incidence')[,c(2,4,5)]
esoph_ages_FC_n <- reshape2::dcast(data = esoph_ages_FC, year ~ age, value.var = "val")
rownames(esoph_ages_FC_n) <- esoph_ages_FC_n$year
esoph_ages_FC_n <- esoph_ages_FC_n[,-1 ]

esoph_ages_FC_n <- esoph_ages_FC_n[,-c(1,2,10)]

#### 补充0-24岁的数据
esoph_ages_FC_n[,'Under 5 years'] <-0
esoph_ages_FC_n[,'5-9 years'] <-0
esoph_ages_FC_n[,'10-14 years'] <-0
esoph_ages_FC_n <- esoph_ages_FC_n[,c(18:20,1:17)]####年龄 从 大到小排列

#数据要为整数
esoph_ages_FC_n <- apply(esoph_ages_FC_n, c(1,2),as.integer) %>% data.frame()
esoph_ages_FC_n <- apply(esoph_ages_FC_n,c(1,2),round) %>% as.data.frame()
#esoph_ages_FC_n <-esoph_ages_FC_n[-c(1:10),]

### for breast
esoph_ages_BC  <- subset(esoph,age %in% ages &
                               metric == 'Number' &
                               cause=='Breast cancer'&
                               measure =='Incidence' &
                               location== 'Global')[,c(4,7,8)]
esoph_ages_BC_n <- reshape2::dcast(data = esoph_ages_BC, year ~ age, value.var = "val")
rownames(esoph_ages_BC_n) <- esoph_ages_BC_n$year
esoph_ages_BC_n <- esoph_ages_BC_n[,-1 ]

esoph_ages_BC_n <-esoph_ages_BC_n[,-c(1,2,10)]

#### 补充0-24岁的数据
esoph_ages_BC_n[,'Under 5 years'] <-0
esoph_ages_BC_n[,'5-9 years'] <-0
esoph_ages_BC_n[,'10-14 years'] <-0

esoph_ages_BC_n <- esoph_ages_BC_n[,c(18:20,1:17)]####年龄 从 大到小排列

#数据要为整数
esoph_ages_BC_n <- apply(esoph_ages_BC_n, c(1,2),as.integer) %>% data.frame()
esoph_ages_BC_n <- apply(esoph_ages_BC_n,c(1,2),round) %>% as.data.frame()
#esoph_ages_BC_n <-esoph_ages_BC_n[-c(1:10),]


### for cervical
esoph_ages_CC  <- subset(esoph,age %in% ages &
                           metric == 'Number' &
                           cause=='Cervical cancer'&
                           measure =='Incidence' &
                           location== 'Global')[,c(4,7,8)]
esoph_ages_CC_n <- reshape2::dcast(data = esoph_ages_CC, year ~ age, value.var = "val")
rownames(esoph_ages_CC_n) <- esoph_ages_CC_n$year
esoph_ages_CC_n <- esoph_ages_CC_n[,-1 ]

esoph_ages_CC_n <-esoph_ages_CC_n[,-c(1,2,10)]

#### 补充0-24岁的数据
esoph_ages_CC_n[,'Under 5 years'] <-0
esoph_ages_CC_n[,'5-9 years'] <-0
esoph_ages_CC_n[,'10-14 years'] <-0

esoph_ages_CC_n <- esoph_ages_CC_n[,c(18:20,1:17)]####年龄 从 大到小排列

#数据要为整数
esoph_ages_CC_n <- apply(esoph_ages_CC_n, c(1,2),as.integer) %>% data.frame()
esoph_ages_CC_n <- apply(esoph_ages_CC_n,c(1,2),round) %>% as.data.frame()
#esoph_ages_CC_n <-esoph_ages_CC_n[-c(1:10),]


### for Uterine
esoph_ages_UC  <- subset(esoph,age %in% ages &
                           metric == 'Number' &
                           cause=='Uterine cancer'&
                           measure =='Incidence' &
                           location== 'Global')[,c(4,7,8)]
esoph_ages_UC_n <- reshape2::dcast(data = esoph_ages_UC, year ~ age, value.var = "val")
rownames(esoph_ages_UC_n) <- esoph_ages_UC_n$year
esoph_ages_UC_n <- esoph_ages_UC_n[,-1 ]

esoph_ages_UC_n <-esoph_ages_UC_n[,-c(1,2,10)]

#### 补充0-24岁的数据
esoph_ages_UC_n[,'Under 5 years'] <-0
esoph_ages_UC_n[,'5-9 years'] <-0
esoph_ages_UC_n[,'10-14 years'] <-0
#esoph_ages_UC_n[,'15-19 years'] <-0 #Deaths

esoph_ages_UC_n <- esoph_ages_UC_n[,c(18:20,1:17)]####年龄 从 大到小排列

#数据要为整数
esoph_ages_UC_n <- apply(esoph_ages_UC_n, c(1,2),as.integer) %>% data.frame()
esoph_ages_UC_n <- apply(esoph_ages_UC_n,c(1,2),round) %>% as.data.frame()
esoph_ages_UC_n <-esoph_ages_UC_n[-c(1:10),]


### for Ovarian
esoph_ages_OC  <- subset(esoph,age %in% ages &
                           metric == 'Number' &
                           cause=='Ovarian cancer'&
                           measure =='Incidence' &
                           location== 'Global')[,c(4,7,8)]

esoph_ages_OC_n <- reshape2::dcast(data = esoph_ages_OC, year ~ age, value.var = "val")
rownames(esoph_ages_OC_n) <- esoph_ages_OC_n$year
esoph_ages_OC_n <- esoph_ages_OC_n[,-1 ]

esoph_ages_OC_n <-esoph_ages_OC_n[,-c(1,2,10)]

#### 补充0-24岁的数据
esoph_ages_OC_n[,'Under 5 years'] <-0
esoph_ages_OC_n[,'5-9 years'] <-0
esoph_ages_OC_n[,'10-14 years'] <-0
#esoph_ages_UC_n[,'15-19'] <-0 #Deaths

esoph_ages_OC_n <- esoph_ages_OC_n[,-c(1,2,10)]####年龄 从 大到小排列
esoph_ages_OC_n <- esoph_ages_OC_n[,c(18:20,1:17)]
#数据要为整数
esoph_ages_OC_n <- apply(esoph_ages_OC_n, c(1,2),as.integer) %>% data.frame()
esoph_ages_OC_n <- apply(esoph_ages_OC_n,c(1,2),round) %>% as.data.frame()
esoph_ages_OC_n <-esoph_ages_OC_n[-c(1:10),]




#获取标准化人口数据(GBD2021)
ages1 <- c("0 to 4","5 to 9","10 to 14","15 to 19","20 to 24",
           "25 to 29","30 to 34","35 to 39","40 to 44","45 to 49",
           "50 to 54","55 to 59","60 to 64","65 to 69","70 to 74",
           "75 to 79","80 to 84","85 to 89","90 to 94","95 plus")
age_stand <- read.csv('GBD2021标准人口组成.csv')
#age_stand <-subset(age_stand,age %in% ages1)
wstand <-c(age_stand$std_population[1:6]%>% as.numeric()%>% sum(),
           age_stand$std_population[7:25]%>% as.numeric()) /sum(age_stand$std_population[1:25])
sum(wstand)



##整理1990-2019人口学数据
ages2 <- c("Under 5","5 to 9","10 to 14","15 to 19","20 to 24",
           "25 to 29","30 to 34","35 to 39","40 to 44","45 to 49",
           "50 to 54","55 to 59","60 to 64","65 to 69","70 to 74",
           "75 to 79","80 to 84","85 to 89","90 to 94","95 plus")
dirname <- dir("D:/组会/GBD/Female-cancer/2021/数据/预测/现实人口数据")  ###读取目录文件夹里的文件
file <- paste0("D:/组会/GBD/Female-cancer/2021/数据/预测/现实人口数据/",dirname)  ### 将文件加上路径
var_name <- c("location_name","sex_name","year_id","age_group_name","val") 
GBD_population  <-  as.data.frame(matrix(nrow=0,ncol=length(var_name)))   #建一个空的数据集，合并文献
names(GBD_population) <- var_name   #将数据集命名
for (a in file) {
  data <- fread(a) %>% select(var_name) %>%
    filter(age_group_name %in% ages2)
  GBD_population <- rbind(GBD_population, data %>% select(all_of(var_name)))#GBD_population <- rbind(GBD_population,data)  
}
GBD_population$sex_name[GBD_population$sex_name=='both'] <-'Both'
GBD_population$sex_name[GBD_population$sex_name=='male'] <-'Male'
GBD_population$sex_name[GBD_population$sex_name=='female'] <- 'Female'
GBD_population <-GBD_population[!duplicated(GBD_population),] #删除重复行

GBD_Global_Male <- subset(GBD_population,location_name=='Global'& sex_name =='Male')
GBD_Global_Female <- subset(GBD_population,location_name=='Global'& sex_name == 'Female')
GBD_Global_Male <- GBD_Global_Male %>% mutate(age_group_name=fct_relevel(age_group_name,ages2)) %>%
  arrange(age_group_name)
GBD_Global_Female <- GBD_Global_Female %>% mutate(age_group_name=fct_relevel(age_group_name,ages2)) %>%
  arrange(age_group_name)
GBD_Global_Male_n <- dcast(data = GBD_Global_Male, year_id ~ age_group_name,value.var = c("val"))
GBD_Global_Female_n <- dcast(data = GBD_Global_Female, year_id ~ age_group_name,value.var = c("val"))


#2020-2030人群数据整理---
prediction_var_name <- c("location_name","sex","year_id","age_group_name" ,"val")
GBD_population_prediction <- fread("2018-2100 人口学数据 GBD.csv") %>%
  select(all_of(prediction_var_name)) %>%
  filter(year_id %in% 2022:2050)

names(GBD_population_prediction) <- var_name #这段代码会按照`var_name`中的顺序和值来更改数据框的列名

GBD_age4 <- GBD_population_prediction %>% subset(age_group_name %in% c("Early Neonatal","Late Neonatal","Post Neonatal","1 to 4")) %>%
  group_by(location_name,sex_name,year_id) %>%
  summarize(val=sum(val))
#GBD_age85 <- GBD_population_prediction %>% subset(age_group_name %in% c("85 to 89","90 to 94","95 plus")) %>%
group_by(location_name,sex_name,year_id) %>%
  summarize(val=sum(val))
GBD_age4$age_group_name <- 'Under 5'
GBD_age4 <- GBD_age4[,c(1:3,5,4)] #调整列的顺序。
#GBD_age85$age_group_name <- '85 plus'
#GBD_age85 <- GBD_age85[,c(1:3,5,4)]
GBD_population_prediction <-subset(GBD_population_prediction,age_group_name %in% ages2)#ages2[-c(1,20)]) #从数据框G中筛选出那些其年龄组在年龄列表 age_2[-c(1,18)](即除去第1和第18个元素外的所有元素)中的行
GBD_population_prediction <- rbind(GBD_population_prediction,GBD_age4)
GBD_population_prediction_Male <- subset(GBD_population_prediction,location_name=='Global'& sex_name =='Male')
GBD_population_prediction_Female <- subset(GBD_population_prediction,location_name=='Global'& sex_name =='Female')
GBD_population_prediction_Male <- GBD_population_prediction_Male %>% mutate(age_group_name=fct_relevel(age_group_name,ages2)) %>%
  arrange(age_group_name)
GBD_population_prediction_Female <- GBD_population_prediction_Female %>% mutate(age_group_name=fct_relevel(age_group_name,ages2)) %>%
  arrange(age_group_name)
GBD_population_prediction_Male_n <- dcast(data = GBD_population_prediction_Male, year_id ~ age_group_name,value.var = c("val"))
GBD_population_prediction_Female_n <- dcast(data = GBD_population_prediction_Female, year_id ~ age_group_name,value.var = c("val"))


#合并1990-2030的人口
GBD_Global_Male_n1 <- rbind(GBD_Global_Male_n ,GBD_population_prediction_Male_n)
GBD_Global_Female_n1 <- rbind(GBD_Global_Female_n ,GBD_population_prediction_Female_n)
GBD_Global_Male_n1 <- as.matrix(GBD_Global_Male_n1)
GBD_Global_Female_n1 <- as.matrix(GBD_Global_Female_n1)
row.names(GBD_Global_Male_n1) <- GBD_Global_Male_n1[,1]
row.names(GBD_Global_Female_n1) <- GBD_Global_Female_n1[,1]
GBD_Global_Male_n1 <- GBD_Global_Male_n1[,-1 ]
GBD_Global_Female_n1 <- GBD_Global_Female_n1[,-1 ]
GBD_Global_Male_n1 <- apply(GBD_Global_Male_n1, c(1,2),as.integer) %>% data.frame()
GBD_Global_Male_n1 <- apply(GBD_Global_Male_n1,c(1,2),round) %>% as.data.frame()
GBD_Global_Female_n1 <- apply(GBD_Global_Female_n1, c(1,2),as.integer) %>% data.frame()
GBD_Global_Female_n1 <- apply(GBD_Global_Female_n1,c(1,2),round) %>% as.data.frame()

GBD_Global_Both_n <- GBD_Global_Male_n1 + GBD_Global_Female_n1



#补充没有发病率数据的年份
esoph_pro <- matrix(data = NA,nrow = 2050-2021,ncol = ncol(esoph_ages_BC_n)) %>% as.data.frame()
rownames(esoph_pro) <- seq(2022,2050,1)
colnames(esoph_pro) <- names(esoph_ages_BC_n)

esoph_ages_FC_n1 <- rbind(esoph_ages_FC_n , esoph_pro)
esoph_ages_BC_n1 <- rbind(esoph_ages_BC_n , esoph_pro)
esoph_ages_CC_n1 <- rbind(esoph_ages_CC_n , esoph_pro)
esoph_ages_UC_n1 <- rbind(esoph_ages_UC_n , esoph_pro)
esoph_ages_OC_n1 <- rbind(esoph_ages_OC_n , esoph_pro)
####行名一致
rownames(esoph_ages_FC_n1) <- rownames(GBD_Global_Female_n1)
rownames(esoph_ages_BC_n1) <- rownames(GBD_Global_Female_n1)
rownames(esoph_ages_CC_n1) <- rownames(GBD_Global_Female_n1)
rownames(esoph_ages_UC_n1) <- rownames(GBD_Global_Female_n1)
rownames(esoph_ages_OC_n1) <- rownames(GBD_Global_Female_n1)
###BAPC模型运行
####模型预测
#colnames(GBD_Global_Female_n1) <- colnames(esoph_ages_BC_n)

FC_esoph <- APCList(esoph_ages_FC_n1, GBD_Global_Female_n1,gf = 5)
FC_bapc_result <- BAPC(FC_esoph,predict = list(npredict = 10,retro = T),
                       secondDiff = FALSE,stdweight = wstand,verbose = F)
                        
BC_esoph <- APCList(esoph_ages_BC_n1, GBD_Global_Female_n1,gf = 5)
BC_bapc_result <- BAPC(BC_esoph,predict = list(npredict = 10,retro = T),
                         secondDiff = FALSE,stdweight = wstand,verbose = F)
CC_esoph <- APCList(esoph_ages_CC_n1, GBD_Global_Female_n1,gf = 5)
CC_bapc_result <- BAPC(CC_esoph,predict = list(npredict = 10,retro = T),
                       secondDiff = FALSE,stdweight = wstand,verbose = F)

UC_esoph <- APCList(esoph_ages_UC_n1, GBD_Global_Female_n1,gf = 5)
UC_bapc_result <- BAPC(UC_esoph,predict = list(npredict = 10,retro = T),
                       secondDiff = FALSE,stdweight = wstand,verbose = F)
OC_esoph <- APCList(esoph_ages_OC_n1, GBD_Global_Female_n1,gf = 5)
OC_bapc_result <- BAPC(OC_esoph,predict = list(npredict = 10,retro = T),
                       secondDiff = FALSE,stdweight = wstand,verbose = F)

PP1 <- plotBAPC(FC_bapc_result, scale=10^5, type = 'ageStdRate', showdata = TRUE)
PP2 <- plotBAPC(BC_bapc_result, scale=10^5, type = 'ageStdRate', showdata = TRUE)
PP3 <- plotBAPC(CC_bapc_result, scale=10^5, type = 'ageStdRate', showdata = TRUE)
PP4 <- plotBAPC(UC_bapc_result, scale=10^5, type = 'ageStdRate', showdata = TRUE)
PP5 <- plotBAPC(OC_bapc_result, scale=10^5, type = 'ageStdRate', showdata = TRUE)

library(eoffice)
topptx(PP1,filename = "FC-ASIR.pptx",width = 8,#图形在宽度
       height = 5#图形在高度
)
topptx(PP2,filename = "BC-ASIR.pptx",width = 8,#图形在宽度
       height = 5#图形在高度
)
topptx(PP3,filename = "CC-ASIR.pptx",width = 8,#图形在宽度
       height = 5#图形在高度
)
topptx(PP4,filename = "UC-ASIR.pptx",width = 8,#图形在宽度
       height = 5#图形在高度
)
topptx(PP5,filename = "OC-ASIR.pptx",width = 8,#图形在宽度
       height = 5#图形在高度
)


#library(magrittr)

####结果获取
#### 不同年龄层发病人数

Female_proj <- agespec.proj(x = FC_bapc_result) %>% as.data.frame()# 查找预测人群
Female_proj_mean <- Female_proj[,colnames(Female_proj) %like% 'mean']
colnames(Female_proj_mean) <- ages2

###计算每个年龄层发病率

Female_rate <- agespec.rate(x = FC_bapc_result) %>% as.data.frame()
Female_rate_mean <- Female_rate[,colnames(Female_rate) %like% 'mean']*100000
colnames(Female_rate_mean) <- ages2

###计算标准发病率
Female_ASR <- agestd.rate(x = FC_bapc_result) %>% as.data.frame()
Female_ASR$mean <- Female_ASR$mean*100000
Female_ASR$year <- rownames(Female_ASR)
write.csv(Female_ASR,'FC-ASIR.csv')

##计算总发病人数

Female_sum_year <- apply(Female_proj_mean, 1, sum) %>% as.data.frame()
colnames(Female_sum_year) <- 'number'
Female_sum_year$year <- rownames(Female_sum_year)


write.csv(Female_sum_year,'FC-Deaths.csv')


####BC
#### 不同年龄层发病人数

Female_proj <- agespec.proj(x = BC_bapc_result) %>% as.data.frame()# 查找预测人群
Female_proj_mean <- Female_proj[,colnames(Female_proj) %like% 'mean']
colnames(Female_proj_mean) <- ages2

###计算每个年龄层发病率

Female_rate <- agespec.rate(x = BC_bapc_result) %>% as.data.frame()
Female_rate_mean <- Female_rate[,colnames(Female_rate) %like% 'mean']*100000
colnames(Female_rate_mean) <- ages2

###计算标准发病率
Female_ASR <- agestd.rate(x = BC_bapc_result) %>% as.data.frame()
Female_ASR$mean <- Female_ASR$mean*100000
Female_ASR$year <- rownames(Female_ASR)
write.csv(Female_ASR,'BC-ASIR.csv')

##计算总发病人数

Female_sum_year <- apply(Female_proj_mean, 1, sum) %>% as.data.frame()
colnames(Female_sum_year) <- 'number'
Female_sum_year$year <- rownames(Female_sum_year)
                                                                                                                                         

write.csv(Female_sum_year,'BC-Deaths.csv')

####Cervical
#### 不同年龄层发病人数

Female_proj <- agespec.proj(x = CC_bapc_result) %>% as.data.frame()# 查找预测人群
Female_proj_mean <- Female_proj[,colnames(Female_proj) %like% 'mean']
colnames(Female_proj_mean) <- ages2

###计算每个年龄层发病率

Female_rate <- agespec.rate(x = CC_bapc_result) %>% as.data.frame()
Female_rate_mean <- Female_rate[,colnames(Female_rate) %like% 'mean']*100000
colnames(Female_rate_mean) <- ages2

###计算标准发病率
Female_ASR <- agestd.rate(x = CC_bapc_result) %>% as.data.frame()
Female_ASR$mean <- Female_ASR$mean*100000
Female_ASR$year <- rownames(Female_ASR)
write.csv(Female_ASR,'CC-ASIR.csv')

##计算总发病人数

Female_sum_year <- apply(Female_proj_mean, 1, sum) %>% as.data.frame()
colnames(Female_sum_year) <- 'number'
Female_sum_year$year <- rownames(Female_sum_year)


write.csv(Female_sum_year,'cC-Deaths.csv')


####uterine

#### 不同年龄层发病人数

Female_proj <- agespec.proj(x = UC_bapc_result) %>% as.data.frame()# 查找预测人群
Female_proj_mean <- Female_proj[,colnames(Female_proj) %like% 'mean']
colnames(Female_proj_mean) <- ages2

###计算每个年龄层发病率

Female_rate <- agespec.rate(x = UC_bapc_result) %>% as.data.frame()
Female_rate_mean <- Female_rate[,colnames(Female_rate) %like% 'mean']*100000
colnames(Female_rate_mean) <- ages2

###计算标准发病率
Female_ASR <- agestd.rate(x = UC_bapc_result) %>% as.data.frame()
Female_ASR$mean <- Female_ASR$mean*100000
Female_ASR$year <- rownames(Female_ASR)
write.csv(Female_ASR,'UC-ASIR.csv')

##计算总发病人数

Female_sum_year <- apply(Female_proj_mean, 1, sum) %>% as.data.frame()
colnames(Female_sum_year) <- 'number'
Female_sum_year$year <- rownames(Female_sum_year)


write.csv(Female_sum_year,'UC-Deaths.csv')

####OVarine
#### 不同年龄层发病人数

Female_proj <- agespec.proj(x = OC_bapc_result) %>% as.data.frame()# 查找预测人群
Female_proj_mean <- Female_proj[,colnames(Female_proj) %like% 'mean']
colnames(Female_proj_mean) <- ages2

###计算每个年龄层发病率

Female_rate <- agespec.rate(x = OC_bapc_result) %>% as.data.frame()
Female_rate_mean <- Female_rate[,colnames(Female_rate) %like% 'mean']*100000
colnames(Female_rate_mean) <- ages2

###计算标准发病率
Female_ASR <- agestd.rate(x = OC_bapc_result) %>% as.data.frame()
Female_ASR$mean <- Female_ASR$mean*100000
Female_ASR$year <- rownames(Female_ASR)
write.csv(Female_ASR,'OC-ASIR.csv')

##计算总发病人数

Female_sum_year <- apply(Female_proj_mean, 1, sum) %>% as.data.frame()
colnames(Female_sum_year) <- 'number'
Female_sum_year$year <- rownames(Female_sum_year)


write.csv(Female_sum_year,'OC-Incidence.csv')

