
setwd('D:/zuhui/GBD/Female-cancer/2021/data')##设置工作路径
install.packages("MASS")
#install.packages("rgdal")
install.packages("sf")
install.packages("terra")###替代rgdal
library(ggmap)
#library(rgdal)
library(sf)
library(terra)
library(ggplot2)
library(maps)
library(dplyr)
library(MASS)
library(boot)
rm(list = ls())

#####FC
################数据处理
EC <- read.csv("FC.csv")
#####合并
EC_number <- subset(EC, age == 'All ages')
EC_number_1 <- subset(EC_number, cause == 'Breast cancer')[, -c(3,4)]

EC_N<- data.frame(measure=EC_number_1$measure,location_name=EC_number_1$location,cause=rep('Female cancer',times=2448),metric=EC_number_1$metric,year=EC_number_1$year,val=rep(0,times=2448),upper=rep(0,times=2448),lower=rep(0,times=2448)) #创建一个数据框
for (i in 1:2448){
  measure_name <- as.character(EC_N[i,1])
  location_name <- as.character(EC_N[i,2])
  cause_name <- as.character(EC_N[i,3])
  metric_name <- as.character(EC_N[i,4])
  year_name <- as.character(EC_N[i,5])
  a <- subset(EC_number, EC_number$measure==measure_name & EC_number$location==location_name & EC_number$cause==cause_name & EC_number$metric == metric_name  & EC_number$year==year_name)  ##取对应地区的数据子集
  val <- sum(a$val)
  upper <- sum(a$upper)
  lower <- sum(a$lower)
  EC_N[i,6] <- val
  EC_N[i,8] <- lower
  EC_N[i,7] <- upper
}

write.csv(EC_N,'FC-N.csv')
EC <- read.csv("FC-N.csv")
EC <-EC_N

#############3另一种合并

# 过滤出所有年龄段的数据
EC_number <- subset(EC, age == 'All ages')

# 筛选出乳腺癌、子宫癌、宫颈癌和卵巢癌的数据
breast_cancer <- subset(EC_number, cause == 'Breast cancer')
uterine_cancer <- subset(EC_number, cause == 'Uterine cancer')
cervical_cancer <- subset(EC_number, cause == 'Cervical cancer')
ovarian_cancer <- subset(EC_number, cause == 'Ovarian cancer')

# 合并所有癌症数据
combined_cancer <- bind_rows(breast_cancer, uterine_cancer, cervical_cancer, ovarian_cancer)

# 聚合数据
EC_N <- combined_cancer %>%
  group_by(measure, location_name, metric, year) %>%
  summarise(
    cause = 'Female cancer',
    val = sum(val, na.rm = TRUE),
    upper = sum(upper, na.rm = TRUE),
    lower = sum(lower, na.rm = TRUE),
    .groups = 'drop'  # This will ensure the data is fully ungrouped after summarising
  )
#write.csv(EC_N,'FC-N.csv')
EC <- read.csv("FC-N.csv")
EC <-EC_N


#SII（斜度不公平指数）-------
#2019年-----
rate2019 <- subset(EC,EC$year ==2021&
                     #EC$age == "All ages" &
                     #EC$sex == 'Female' &  
                     EC$metric == 'Rate' &
                     #EC$cause == 'Ovarian cancer' &
                     EC$measure == 'Deaths'
                   )[ , c(2, 6, 7,8)]

#合并SDI和人口学数据(Georgia重复）
SDII <- read.csv('SDI1990-2019modified.csv')
SDII <- plyr::rename(SDII,c(location="location_name"))
SDII <- subset(SDII,SDII$year==2021)
SDII <- SDII[,c(1,3)]

Population <- read.csv('population.CSV',header = T)
Population <- subset(Population, 
                     Population$sex_name == 'female' & 
                       Population$age_group_name == "All Ages" & 
                       Population$year_id == 2021)
Total_Population <- data.frame(location_name=rate2019$location_name,number=rep(0,times=204)) #创建一个数据框
for (i in 1:204){
  location_name_name <- as.character(Total_Population[i,1])
  a <- subset(Population, Population$location_name==location_name_name)  ##取对应地区的数据子集
  number <- sum(a$val)
  Total_Population[i,2] <- number
  
}
Total<- left_join(rate2019 ,Total_Population,by=c('location_name')) 
Total<- left_join(Total,SDII,by=c('location_name')) 
Total$SE <- (Total$upper-Total$lower)/(1.96*2) 
Total[,'year'] <-2021 
Total <- Total %>% arrange(SDI)
#write.csv(Total,'2019rate-BC.csv')   #自己去excel里面处理把SDI按照从小到大排序
#Total <- read.csv('2019rate-BC.csv',header = T)

# 然后，我们计算每个国家的人口占比
Total$cum_population <- Total$number / sum(Total$number)
#Total$Midpoint <- c(0, Total$cum_population[1:(nrow(Total)-1)]) / 2 + Total$cum_population / 2
#求累积人口占比
Total$new1 <- c(0, cumsum(Total$cum_population[1:(nrow(Total)-1)]))
Total$new2 <- cumsum(Total$cum_population)
#求累积人口占比的中点
Total$Midpoint <- (Total$new1 + Total$new2) / 2

#重复迭代加权线性回归
# install.packages("MASS")
library(MASS)
model <- rlm(val ~ Midpoint, data = Total)
# 斜率不等性指数就是回归系数
sii <- coef(model)["Midpoint"]
#计算95%置信区间
# 创建一个新的confint方法，适用于rlm对象
confint.rlm <- function (object, ...) {
  object$df.residual <- MASS:::summary.rlm(object)$df[2]
  confint.lm(object, ...)
}
# 使用新的方法计算置信区间
confint.rlm(model)



#1990年-----
rate1990 <- subset(EC,EC$year ==1990&
                     #EC$age == "All ages" &
                     #EC$sex == 'Both' &  
                     EC$metric == 'Rate' &
                     #EC$cause == 'Ovarian cancer' &
                     EC$measure == 'Deaths'
                    )[ , c(2, 6, 7, 8)]

#合并SDI和人口学数据
SDII <- read.csv('SDI1990-2019modified.csv')
SDII <- plyr::rename(SDII,c(location="location_name"))
SDII <- subset(SDII,SDII$year==1990)
SDII <- SDII[,c(1,3)]
Population <- read.csv('population.CSV',header = T)
Population <- subset(Population, 
                     Population$sex_name == 'female' & 
                       Population$age_group_name == "All Ages" & 
                       Population$year_id == 1990)
Total_Population <- data.frame(location_name=rate1990$location_name,number=rep(0,times=204)) #创建一个数据框
for (i in 1:204){
  location_name_name <- as.character(Total_Population[i,1])
  a <- subset(Population, Population$location_name==location_name_name)  ##取对应地区的数据子集
  number <- sum(a$val)
  Total_Population[i,2] <- number
  
}
Total1<- left_join(rate1990 ,Total_Population,by=c('location_name')) 
Total1<- left_join(Total1,SDII,by=c('location_name')) 
Total1$SE <- (Total1$upper-Total1$lower)/(1.96*2) 
Total1[,'year'] <-1990
Total1 <- Total1 %>% arrange(SDI)
#write.csv(Total1,'1990rate-BC.csv')   #去excel里面处理，把SDI按照从小到大排序
#Total1 <- read.csv('1990rate-BC.csv',header = T)


# 然后，我们计算每个国家的人口占比
Total1$cum_population <- Total1$number / sum(Total1$number)
#Total1$Midpoint <- c(0, Total1$cum_population[1:(nrow(Total1)-1)]) / 2 + Total1$cum_population / 2
#求累积人口占比
Total1$new1 <- c(0, cumsum(Total1$cum_population[1:(nrow(Total1)-1)]))
Total1$new2 <- cumsum(Total1$cum_population)
#求累积人口占比的中点
Total1$Midpoint <- (Total1$new1 + Total1$new2) / 2

#重复迭代加权线性回归
model1 <- rlm(val ~ Midpoint, data = Total1)
# 斜率不等性指数就是回归系数
sii <- coef(model1)["Midpoint"]
#计算95%置信区间
# 创建一个新的confint方法，适用于rlm对象
confint.rlm <- function (object, ...) {
  object$df.residual <- MASS:::summary.rlm(object)$df[2]
  confint.lm(object, ...)
}
# 使用新的方法计算置信区间
confint.rlm(model1)


###画图,合在一起-----
Total_rate_combined <- rbind(Total, Total1)

# 按年份分组，并对每一组进行重复迭代加权线性回归
Total_rate_combined <- Total_rate_combined %>%
  group_by(year) %>%
  do({
    model <- rlm(val ~ Midpoint, data = .)
    data.frame(., pred = predict(model, newdata = .,interval = "confidence"))
  })

summary(model)


# 绘图
library(ggplot2)
library(dplyr)
A <- Total_rate_combined %>% 
  ggplot(aes(x = Midpoint, y = val, color = factor(year))) +  # 将年份转换为因子
  geom_point(aes(size = number)) +  # 设置空心圆形状和填充颜色
  geom_line(aes(y=pred.fit),size=0.7) +  # 添加线条，设置线条颜色
  geom_ribbon(data = subset(Total_rate_combined, year==1990),aes(ymin = pred.lwr, ymax = pred.upr), fill = "#c94741",color = NA, alpha = 0.2) +  # 添加预测的置信区间
  geom_ribbon(data = subset(Total_rate_combined, year==2021),aes(ymin = pred.lwr, ymax = pred.upr), fill = "#4593c3",color = NA,alpha = 0.2)+
  labs(x = "Relative rank by SDI", 
       y = "Crude mortality rate (per 100,000)", 
       color = "year") +
  theme_bw() +  # 使用白色背景的主题
  scale_color_manual(values = c("#FF3333", "#33CCCC"))+  # 设置曲线颜色映射
  geom_linerange(aes(xmin = 0, xmax = 1, y = 0.3116923), color = "#FF3333",lty = 3,size =0.7) +  
  geom_linerange(aes(xmin = 0, xmax = 1, y = 1.2722551), color = "#33CCCC",lty = 3,size =0.7)+
  scale_size_continuous(
    limits = c(0, 800000000),
    breaks = seq(200000000, 800000000, by = 200000000),
    labels = function(x) paste0(x / 1000000),
    range = c(0.2, 3.4)  # 设置圆圈大小范围从最小到最大
  ) +  # 设置标签为以 "million" 为单位的文本
  guides(color = guide_legend(override.aes = list(shape = 16, size = 1.5),title = "year"))+ # 设置图例项的填充色为白色，形状为圆圈
  guides(size = guide_legend(override.aes = list(fill = "white", shape = 1), title = "Population\n (million)"))+
  theme(
    axis.line = element_line(color = "black",size = 0.5),
    panel.border = element_rect(color = "black", size = 0.5, fill = NA),  # 设置面板边框的颜色和大小
    panel.grid.major = element_line(size = 0.5),  
    panel.grid.minor = element_line(size = 0.5),  
    axis.title = element_text(size = 10,family = "serif",color = "black"),  # 设置坐标轴标题的字体大小和加粗
    axis.text = element_text(size = 10,family = "serif",color = "black"),  # 设置坐标轴标签的字体大小
    legend.text = element_text(size = 10,family = "serif",color = "black"),  # 设置图例文本的字体大小
    legend.title = element_text(size = 10,family = "serif",color = "black"))+  # 设置图例标题的字体大小
  theme(
    axis.text.x = element_text(margin = margin(t = 3, r = 0, b = 0, l = 0)),  # 调整X轴刻度与轴的距离
    axis.text.y = element_text(margin = margin(t = 0, r = 3, b = 0, l = 0)),  # 调整Y轴刻度与轴的距离
    axis.title.x = element_text(margin = margin(t = 5, r = 0, b = 0, l = 0)),  # 调整X轴标题与轴的距离
    axis.title.y = element_text(margin = margin(t = 0, r = 5, b = 0, l = 0)))
#+scale_x_continuous(limits = c(0, 1.125),breaks = seq(0,1.00,by = 0.25))
#scale_y_continuous(limits = c(0, 20)) # 设置y轴刻度范围从0到10)  # 调整Y轴标题与轴的距离

print(A)

library(eoffice) #加载包，将图导出为PPTX
topptx(A,filename = "Mortality FC-rate.pptx",
       width = 8, height = 5)#将生存曲线保存在ppt中




##集中指数画图------
#2019年-----

number2019 <- subset(EC,EC$year ==2021&
                 #EC$age == "All ages" &
                 EC$metric == 'Number' &
                 #EC$cause == 'Ovarian cancer' &
                 EC$measure == 'Deaths'
                 )[ , c(2, 6, 7, 8)]
#合并SDI和人口学数据
SDII <- read.csv('SDI1990-2019modified.csv')
SDII <- plyr::rename(SDII,c(location="location_name"))
SDII <- subset(SDII,SDII$year==2021)
SDII <- SDII[,c(1,3)]
Population <- read.csv('population.CSV',header = T)
Population <- subset(Population, 
                     Population$sex_name == 'female' & 
                       Population$age_group_name == "All Ages" & 
                       Population$year_id == 2021)
Total_Population <- data.frame(location_name=number2019$location_name,number=rep(0,times=204)) #创建一个数据框
for (i in 1:204){
  location_name_name <- as.character(Total_Population[i,1])
  a <- subset(Population, Population$location_name==location_name_name)  ##取对应地区的数据子集
  number <- sum(a$val)
  Total_Population[i,2] <- number
  
}
Total<- left_join(number2019 ,Total_Population,by=c('location_name')) 
Total<- left_join(Total,SDII,by=c('location_name')) 
Total$SE <- (Total$upper-Total$lower)/(1.96*2) 
Total[,'year'] <-2021
Total <- Total %>% arrange(SDI)
#write.csv(Total,'2019number-BC.csv')   #自己去excel里面处理把SDI按照从小到大排序


# 然后，我们计算每个国家的人口占比
Total$cum_population <- Total$number / sum(Total$number)
#Total$Midpoint <- c(0, Total$cum_population[1:(nrow(Total)-1)]) / 2 + Total$cum_population / 2

#求累积人口占比
Total$new1 <- c(0, cumsum(Total$cum_population[1:(nrow(Total)-1)]))
Total$new2 <- cumsum(Total$cum_population)
#求累积人口占比的中点
Total$Midpoint <- (Total$new1 + Total$new2) / 2

Total$cum_DALYs <- Total$val / sum(Total$val)
Total$yDALYs <- cumsum(Total$cum_DALYs)


# 假设 Total_combined_number 已经按照 new2 排序
# 计算洛伦兹曲线下的面积，使用梯形法则
lorenz_curve_area <- with(Total, sum(diff(new2) * (yDALYs[-length(yDALYs)] + yDALYs[-1])/2))

# 计算基尼系数
gini_coefficient <- 1 - 2 * lorenz_curve_area

# 打印基尼系数
print(gini_coefficient)

calculate_gini <- function(df) {
  # 确保数据按照累积人口占比排序
  df <- df[order(df$new2), ]
  # 计算洛伦兹曲线下的面积（梯形法则）
  lorenz_curve_area <- sum(diff(df$new2) * (df$yDALYs[-length(df$yDALYs)] + df$yDALYs[-1]) / 2)
  # 计算基尼系数
  gini_coefficient <- 1 - 2 * lorenz_curve_area
  return(gini_coefficient)
}
set.seed(123)  # 设置随机数种子以确保结果可重现
# 自助法重抽样次数
n_bootstrap <- 1000
bootstrap_ginis <- numeric(n_bootstrap)  # 初始化保存基尼系数的向量

for (i in 1:n_bootstrap) {
  sampled_data <- Total[sample(nrow(Total), replace = TRUE), ]  # 带替换地随机抽样
  bootstrap_ginis[i] <- calculate_gini(sampled_data)  # 计算并保存基尼系数
}

# 计算95%置信区间
gini_ci <- quantile(bootstrap_ginis, probs = c(0.025, 0.975))
print(gini_ci)


#1990年-----
number1990 <- subset(EC,EC$year ==1990&
                       #EC$age == "All ages" &
                       EC$metric == 'Number' &
                       #EC$cause == 'Ovarian cancer' &
                       EC$measure == 'Deaths'
                       )[ , c(2, 6, 7, 8)]

#合并SDI和人口学数据
SDII <- read.csv('SDI1990-2019modified.csv')
SDII <- plyr::rename(SDII,c(location="location_name"))
SDII <- subset(SDII,SDII$year==1990)
SDII <- SDII[,c(1,3)]
Population <- read.csv('population.CSV',header = T)
Population <- subset(Population, 
                     Population$sex_name == 'female' & 
                       Population$age_group_name == "All Ages" & 
                       Population$year_id == 1990)
Total_Population <- data.frame(location_name=number1990$location_name,number=rep(0,times=204)) #创建一个数据框
for (i in 1:204){
  location_name_name <- as.character(Total_Population[i,1])
  a <- subset(Population, Population$location_name==location_name_name)  ##取对应地区的数据子集
  number <- sum(a$val)
  Total_Population[i,2] <- number
  
}
Total1<- left_join(number1990 ,Total_Population,by=c('location_name')) 
Total1<- left_join(Total1,SDII,by=c('location_name')) 
Total1$SE <- (Total1$upper-Total1$lower)/(1.96*2) 
Total1[,'year'] <-1990
Total1 <- Total1 %>% arrange(SDI)
#write.csv(Total1,'1990number-BC.csv')   #去excel里面处理，把SDI按照从小到大排序


# 然后，我们计算每个国家的人口占比
Total1$cum_population <- Total1$number / sum(Total1$number)
#Total$Midpoint <- c(0, Total$cum_population[1:(nrow(Total)-1)]) / 2 + Total$cum_population / 2

#求累积人口占比
Total1$new1 <- c(0, cumsum(Total1$cum_population[1:(nrow(Total1)-1)]))
Total1$new2 <- cumsum(Total1$cum_population)
#求累积人口占比的中点
Total1$Midpoint <- (Total1$new1 + Total1$new2) / 2

Total1$cum_DALYs <- Total1$val / sum(Total1$val)
Total1$yDALYs <- cumsum(Total1$cum_DALYs)
# 假设 Total_combined_number 已经按照 new2 排序
# 计算洛伦兹曲线下的面积，使用梯形法则
lorenz_curve_area <- with(Total1, sum(diff(new2) * (yDALYs[-length(yDALYs)] + yDALYs[-1])/2))

# 计算基尼系数
gini_coefficient <- 1 - 2 * lorenz_curve_area

# 打印基尼系数
print(gini_coefficient)

calculate_gini <- function(df) {
  # 确保数据按照累积人口占比排序
  df <- df[order(df$new2), ]
  # 计算洛伦兹曲线下的面积（梯形法则）
  lorenz_curve_area <- sum(diff(df$new2) * (df$yDALYs[-length(df$yDALYs)] + df$yDALYs[-1]) / 2)
  # 计算基尼系数
  gini_coefficient <- 1 - 2 * lorenz_curve_area
  return(gini_coefficient)
}
set.seed(123)  # 设置随机数种子以确保结果可重现
# 自助法重抽样次数
n_bootstrap <- 1000
bootstrap_ginis <- numeric(n_bootstrap)  # 初始化保存基尼系数的向量

for (i in 1:n_bootstrap) {
  sampled_data <- Total1[sample(nrow(Total1), replace = TRUE), ]  # 带替换地随机抽样
  bootstrap_ginis[i] <- calculate_gini(sampled_data)  # 计算并保存基尼系数
}

# 计算95%置信区间
gini_ci <- quantile(bootstrap_ginis, probs = c(0.025, 0.975))
print(gini_ci)



#合在一起----
Total_combined_number <- rbind(Total, Total1)
A <- Total_combined_number %>% 
  ggplot(aes(x = new2, y = yDALYs, color = factor(year))) +  # 将年份转换为因子
  geom_point(aes(size = number)) +  # 设置空心圆形状和填充颜色
  geom_line(size=0.7) +  # 添加线条，设置线条颜色
  labs(x = "Cumulative fraction of population ranked by SDI", 
       y = "Cumulative fraction of mortality", 
       color = "year") +
  geom_segment(aes(x = 0, xend =1, y = 0, yend = 1), color = "#DEB348", size= 0.7) +  
  geom_linerange(aes(x = 1, ymin = 0, ymax = 1), color = "grey",size =0.7) +  
  geom_linerange(aes(xmin =0, xmax = 1, y = 0), color = "grey",size =0.7)+ 
  theme_bw() +  # 使用白色背景的主题
  scale_color_manual(values = c("#FF3333", "#33CCCC"))+  # 设置曲线颜色映射
  scale_size_continuous(
    limits = c(0, 800000000),
    breaks = seq(200000000, 800000000, by = 200000000),
    labels = function(x) paste0(x / 1000000),
    range = c(0.2, 3.4)  # 设置圆圈大小范围从最小到最大
  ) +  # 设置标签为以 "million" 为单位的文本
  guides(size = guide_legend(override.aes = list(fill = "white", shape = 1), title = "Population\n (million)"))+
  guides(color = guide_legend(override.aes = list(shape = 16, size = 1.5),title = "year"))+ # 设置图例项的填充色为白色，形状为圆圈
  theme(
    axis.line = element_line(color = "black",size = 0.5),
    panel.border = element_rect(color = "black", size = 0.5, fill = NA),  # 设置面板边框的颜色和大小
    panel.grid.major = element_line(size = 0.5),  
    panel.grid.minor = element_line(size = 0.5),  
    axis.title = element_text(size = 10,family = "serif",color = "black"),  # 设置坐标轴标题的字体大小和加粗
    axis.text = element_text(size = 10,family = "serif",color = "black"),  # 设置坐标轴标签的字体大小
    legend.text = element_text(size = 10,family = "serif",color = "black"),  # 设置图例文本的字体大小
    legend.title = element_text(size = 10,family = "serif",color = "black"))+  # 设置图例标题的字体大小
  theme(
    axis.text.x = element_text(margin = margin(t = 3, r = 0, b = 0, l = 0)),  # 调整X轴刻度与轴的距离
    axis.text.y = element_text(margin = margin(t = 0, r = 3, b = 0, l = 0)),  # 调整Y轴刻度与轴的距离
    axis.title.x = element_text(margin = margin(t = 5, r = 0, b = 0, l = 0)),  # 调整X轴标题与轴的距离
    axis.title.y = element_text(margin = margin(t = 0, r = 5, b = 0, l = 0)))  # 调整Y轴标题与轴的距离

print(A)


###结果输出
#ggsave("DALYs number-Neoplasms-both.PDF",width=8,height=5,units="in",dpi=300)

topptx(A,filename = "Mortality number-FC.pptx",width = 8,#图形在宽度
       height = 5#图形在高度
)





########BC 
 EC <- read.csv("疾病数据.csv")

#SII（斜度不公平指数）-------
#2019年-----
rate2019 <- subset(EC,EC$year ==2021&
                     EC$age == "All ages" &
                     #EC$sex == 'Female' &  
                     EC$metric == 'Rate' &
                     EC$cause == 'Breast cancer' &
                     EC$measure == 'Deaths'
)[ , c(2, 8, 9,10)]

#合并SDI和人口学数据(Georgia重复）
SDII <- read.csv('SDI1990-2019modified.csv')
SDII <- plyr::rename(SDII,c(location="location_name"))
SDII <- subset(SDII,SDII$year==2021)
SDII <- SDII[,c(1,3)]

Population <- read.csv('population.CSV',header = T)
Population <- subset(Population, 
                     Population$sex_name == 'female' & 
                       Population$age_group_name == "All Ages" & 
                       Population$year_id == 2021)
Total_Population <- data.frame(location_name=rate2019$location,number=rep(0,times=204)) #创建一个数据框
for (i in 1:204){
  location_name_name <- as.character(Total_Population[i,1])
  a <- subset(Population, Population$location_name==location_name_name)  ##取对应地区的数据子集
  number <- sum(a$val)
  Total_Population[i,2] <- number
  
}
Total<- left_join(rate2019 ,Total_Population,by=c('location_name')) 
Total<- left_join(Total,SDII,by=c('location_name')) 
Total$SE <- (Total$upper-Total$lower)/(1.96*2) 
Total[,'year'] <-2021 
Total <- Total %>% arrange(SDI)
#write.csv(Total,'2019rate-BC.csv')   #自己去excel里面处理把SDI按照从小到大排序
#Total <- read.csv('2019rate-BC.csv',header = T)

# 然后，我们计算每个国家的人口占比
Total$cum_population <- Total$number / sum(Total$number)
#Total$Midpoint <- c(0, Total$cum_population[1:(nrow(Total)-1)]) / 2 + Total$cum_population / 2
#求累积人口占比
Total$new1 <- c(0, cumsum(Total$cum_population[1:(nrow(Total)-1)]))
Total$new2 <- cumsum(Total$cum_population)
#求累积人口占比的中点
Total$Midpoint <- (Total$new1 + Total$new2) / 2

#重复迭代加权线性回归
# install.packages("MASS")
library(MASS)
model <- rlm(val ~ Midpoint, data = Total)
# 斜率不等性指数就是回归系数
sii <- coef(model)["Midpoint"]
#计算95%置信区间
# 创建一个新的confint方法，适用于rlm对象
confint.rlm <- function (object, ...) {
  object$df.residual <- MASS:::summary.rlm(object)$df[2]
  confint.lm(object, ...)
}
# 使用新的方法计算置信区间
confint.rlm(model)

#1990年-----
rate1990 <- subset(EC,EC$year ==1990&
                     EC$age == "All ages" &
                     #EC$sex == 'Both' &  
                     EC$metric == 'Rate' &
                     EC$cause == 'Breast cancer' &
                     EC$measure == 'Deaths'
)[ , c(2, 8, 9, 10)]

#合并SDI和人口学数据
SDII <- read.csv('SDI1990-2019modified.csv')
SDII <- plyr::rename(SDII,c(location="location_name"))
SDII <- subset(SDII,SDII$year==1990)
SDII <- SDII[,c(1,3)]
Population <- read.csv('population.CSV',header = T)
Population <- subset(Population, 
                     Population$sex_name == 'female' & 
                       Population$age_group_name == "All Ages" & 
                       Population$year_id == 1990)
Total_Population <- data.frame(location_name=rate1990$location_name,number=rep(0,times=204)) #创建一个数据框
for (i in 1:204){
  location_name_name <- as.character(Total_Population[i,1])
  a <- subset(Population, Population$location_name==location_name_name)  ##取对应地区的数据子集
  number <- sum(a$val)
  Total_Population[i,2] <- number
  
}
Total1<- left_join(rate1990 ,Total_Population,by=c('location_name')) 
Total1<- left_join(Total1,SDII,by=c('location_name')) 
Total1$SE <- (Total1$upper-Total1$lower)/(1.96*2) 
Total1[,'year'] <-1990
Total1 <- Total1 %>% arrange(SDI)
#write.csv(Total1,'1990rate-BC.csv')   #去excel里面处理，把SDI按照从小到大排序
#Total1 <- read.csv('1990rate-BC.csv',header = T)

# 然后，我们计算每个国家的人口占比
Total1$cum_population <- Total1$number / sum(Total1$number)
#Total1$Midpoint <- c(0, Total1$cum_population[1:(nrow(Total1)-1)]) / 2 + Total1$cum_population / 2
#求累积人口占比
Total1$new1 <- c(0, cumsum(Total1$cum_population[1:(nrow(Total1)-1)]))
Total1$new2 <- cumsum(Total1$cum_population)
#求累积人口占比的中点
Total1$Midpoint <- (Total1$new1 + Total1$new2) / 2

#重复迭代加权线性回归
model1 <- rlm(val ~ Midpoint, data = Total1)
# 斜率不等性指数就是回归系数
sii <- coef(model1)["Midpoint"]
#计算95%置信区间
# 创建一个新的confint方法，适用于rlm对象
confint.rlm <- function (object, ...) {
  object$df.residual <- MASS:::summary.rlm(object)$df[2]
  confint.lm(object, ...)
}
# 使用新的方法计算置信区间
confint.rlm(model1)


###画图,合在一起-----
Total_rate_combined <- rbind(Total, Total1)

# 按年份分组，并对每一组进行重复迭代加权线性回归
Total_rate_combined <- Total_rate_combined %>%
  group_by(year) %>%
  do({
    model <- rlm(val ~ Midpoint, data = .)
    data.frame(., pred = predict(model, newdata = .,interval = "confidence"))
  })

summary(model)


# 绘图
library(ggplot2)
library(dplyr)
A <- Total_rate_combined %>% 
  ggplot(aes(x = Midpoint, y = val, color = factor(year))) +  # 将年份转换为因子
  geom_point(aes(size = number)) +  # 设置空心圆形状和填充颜色
  geom_line(aes(y=pred.fit),size=0.7) +  # 添加线条，设置线条颜色
  geom_ribbon(data = subset(Total_rate_combined, year==1990),aes(ymin = pred.lwr, ymax = pred.upr), fill = "#c94741",color = NA, alpha = 0.2) +  # 添加预测的置信区间
  geom_ribbon(data = subset(Total_rate_combined, year==2021),aes(ymin = pred.lwr, ymax = pred.upr), fill = "#4593c3",color = NA,alpha = 0.2)+
  labs(x = "Relative rank by SDI", 
       y = "Crude mortality rate (per 100,000)", 
       color = "year") +
  theme_bw() +  # 使用白色背景的主题
  scale_color_manual(values = c("#FF3333", "#33CCCC"))+  # 设置曲线颜色映射
  geom_linerange(aes(xmin = 0, xmax = 1, y = 0.3116923), color = "#FF3333",lty = 3,size =0.7) +  
  geom_linerange(aes(xmin = 0, xmax = 1, y = 1.2722551), color = "#33CCCC",lty = 3,size =0.7)+
  scale_size_continuous(
    limits = c(0, 800000000),
    breaks = seq(200000000, 800000000, by = 200000000),
    labels = function(x) paste0(x / 1000000),
    range = c(0.2, 3.4)  # 设置圆圈大小范围从最小到最大
  ) +  # 设置标签为以 "million" 为单位的文本
  guides(color = guide_legend(override.aes = list(shape = 16, size = 1.5),title = "year"))+ # 设置图例项的填充色为白色，形状为圆圈
  guides(size = guide_legend(override.aes = list(fill = "white", shape = 1), title = "Population\n (million)"))+
  theme(
    axis.line = element_line(color = "black",size = 0.5),
    panel.border = element_rect(color = "black", size = 0.5, fill = NA),  # 设置面板边框的颜色和大小
    panel.grid.major = element_line(size = 0.5),  
    panel.grid.minor = element_line(size = 0.5),  
    axis.title = element_text(size = 10,family = "serif",color = "black"),  # 设置坐标轴标题的字体大小和加粗
    axis.text = element_text(size = 10,family = "serif",color = "black"),  # 设置坐标轴标签的字体大小
    legend.text = element_text(size = 10,family = "serif",color = "black"),  # 设置图例文本的字体大小
    legend.title = element_text(size = 10,family = "serif",color = "black"))+  # 设置图例标题的字体大小
  theme(
    axis.text.x = element_text(margin = margin(t = 3, r = 0, b = 0, l = 0)),  # 调整X轴刻度与轴的距离
    axis.text.y = element_text(margin = margin(t = 0, r = 3, b = 0, l = 0)),  # 调整Y轴刻度与轴的距离
    axis.title.x = element_text(margin = margin(t = 5, r = 0, b = 0, l = 0)),  # 调整X轴标题与轴的距离
    axis.title.y = element_text(margin = margin(t = 0, r = 5, b = 0, l = 0)))
   #+scale_x_continuous(limits = c(0, 1.125),breaks = seq(0,1.00,by = 0.25))
   #scale_y_continuous(limits = c(0, 20)) # 设置y轴刻度范围从0到10)  # 调整Y轴标题与轴的距离
   
print(A)

library(eoffice) #加载包，将图导出为PPTX
topptx(A,filename = "Mortality BC-rate.pptx",
       width =8, height = 5)#将生存曲线保存在ppt中


##集中指数画图-----Number
#2019年-----

number2019 <- subset(EC,EC$year ==2021&
                       EC$age == "All ages" &
                       EC$metric == 'Number' &
                       EC$cause == 'Breast cancer' &
                       EC$measure == 'Deaths'
)[ , c(2, 8, 9, 10)]
#合并SDI和人口学数据
SDII <- read.csv('SDI1990-2019modified.csv')
SDII <- plyr::rename(SDII,c(location="location_name"))
SDII <- subset(SDII,SDII$year==2021)
SDII <- SDII[,c(1,3)]
Population <- read.csv('population.CSV',header = T)
Population <- subset(Population, 
                     Population$sex_name == 'female' & 
                       Population$age_group_name == "All Ages" & 
                       Population$year_id == 2021)
Total_Population <- data.frame(location_name=number2019$location_name,number=rep(0,times=204)) #创建一个数据框
for (i in 1:204){
  location_name_name <- as.character(Total_Population[i,1])
  a <- subset(Population, Population$location_name==location_name_name)  ##取对应地区的数据子集
  number <- sum(a$val)
  Total_Population[i,2] <- number
  
}
Total<- left_join(number2019 ,Total_Population,by=c('location_name')) 
Total<- left_join(Total,SDII,by=c('location_name')) 
Total$SE <- (Total$upper-Total$lower)/(1.96*2) 
Total[,'year'] <-2021
Total <- Total %>% arrange(SDI)
#write.csv(Total,'2019number-BC.csv')   #自己去excel里面处理把SDI按照从小到大排序


# 然后，我们计算每个国家的人口占比
Total$cum_population <- Total$number / sum(Total$number)
#Total$Midpoint <- c(0, Total$cum_population[1:(nrow(Total)-1)]) / 2 + Total$cum_population / 2

#求累积人口占比
Total$new1 <- c(0, cumsum(Total$cum_population[1:(nrow(Total)-1)]))
Total$new2 <- cumsum(Total$cum_population)
#求累积人口占比的中点
Total$Midpoint <- (Total$new1 + Total$new2) / 2

Total$cum_DALYs <- Total$val / sum(Total$val)
Total$yDALYs <- cumsum(Total$cum_DALYs)


# 假设 Total_combined_number 已经按照 new2 排序
# 计算洛伦兹曲线下的面积，使用梯形法则
lorenz_curve_area <- with(Total, sum(diff(new2) * (yDALYs[-length(yDALYs)] + yDALYs[-1])/2))

# 计算基尼系数
gini_coefficient <- 1 - 2 * lorenz_curve_area

# 打印基尼系数
print(gini_coefficient)

calculate_gini <- function(df) {
  # 确保数据按照累积人口占比排序
  df <- df[order(df$new2), ]
  # 计算洛伦兹曲线下的面积（梯形法则）
  lorenz_curve_area <- sum(diff(df$new2) * (df$yDALYs[-length(df$yDALYs)] + df$yDALYs[-1]) / 2)
  # 计算基尼系数
  gini_coefficient <- 1 - 2 * lorenz_curve_area
  return(gini_coefficient)
}
set.seed(123)  # 设置随机数种子以确保结果可重现
# 自助法重抽样次数
n_bootstrap <- 1000
bootstrap_ginis <- numeric(n_bootstrap)  # 初始化保存基尼系数的向量

for (i in 1:n_bootstrap) {
  sampled_data <- Total[sample(nrow(Total), replace = TRUE), ]  # 带替换地随机抽样
  bootstrap_ginis[i] <- calculate_gini(sampled_data)  # 计算并保存基尼系数
}

# 计算95%置信区间
gini_ci <- quantile(bootstrap_ginis, probs = c(0.025, 0.975))
print(gini_ci)


#1990年-----
number1990 <- subset(EC,EC$year ==1990&
                       EC$age == "All ages" &
                       EC$metric == 'Number' &
                       EC$cause == 'Breast cancer' &
                       EC$measure == 'Deaths'
)[ , c(2, 8, 9, 10)]

#合并SDI和人口学数据
SDII <- read.csv('SDI1990-2019modified.csv')
SDII <- plyr::rename(SDII,c(location="location_name"))
SDII <- subset(SDII,SDII$year==1990)
SDII <- SDII[,c(1,3)]
Population <- read.csv('population.CSV',header = T)
Population <- subset(Population, 
                     Population$sex_name == 'female' & 
                       Population$age_group_name == "All Ages" & 
                       Population$year_id == 1990)
Total_Population <- data.frame(location_name=number1990$location_name,number=rep(0,times=204)) #创建一个数据框
for (i in 1:204){
  location_name_name <- as.character(Total_Population[i,1])
  a <- subset(Population, Population$location_name==location_name_name)  ##取对应地区的数据子集
  number <- sum(a$val)
  Total_Population[i,2] <- number
  
}
Total1<- left_join(number1990 ,Total_Population,by=c('location_name')) 
Total1<- left_join(Total1,SDII,by=c('location_name')) 
Total1$SE <- (Total1$upper-Total1$lower)/(1.96*2) 
Total1[,'year'] <-1990
Total1 <- Total1 %>% arrange(SDI)
#write.csv(Total1,'1990number-BC.csv')   #去excel里面处理，把SDI按照从小到大排序


# 然后，我们计算每个国家的人口占比
Total1$cum_population <- Total1$number / sum(Total1$number)
#Total$Midpoint <- c(0, Total$cum_population[1:(nrow(Total)-1)]) / 2 + Total$cum_population / 2

#求累积人口占比
Total1$new1 <- c(0, cumsum(Total1$cum_population[1:(nrow(Total1)-1)]))
Total1$new2 <- cumsum(Total1$cum_population)
#求累积人口占比的中点
Total1$Midpoint <- (Total1$new1 + Total1$new2) / 2

Total1$cum_DALYs <- Total1$val / sum(Total1$val)
Total1$yDALYs <- cumsum(Total1$cum_DALYs)
# 假设 Total_combined_number 已经按照 new2 排序
# 计算洛伦兹曲线下的面积，使用梯形法则
lorenz_curve_area <- with(Total1, sum(diff(new2) * (yDALYs[-length(yDALYs)] + yDALYs[-1])/2))

# 计算基尼系数
gini_coefficient <- 1 - 2 * lorenz_curve_area

# 打印基尼系数
print(gini_coefficient)

calculate_gini <- function(df) {
  # 确保数据按照累积人口占比排序
  df <- df[order(df$new2), ]
  # 计算洛伦兹曲线下的面积（梯形法则）
  lorenz_curve_area <- sum(diff(df$new2) * (df$yDALYs[-length(df$yDALYs)] + df$yDALYs[-1]) / 2)
  # 计算基尼系数
  gini_coefficient <- 1 - 2 * lorenz_curve_area
  return(gini_coefficient)
}
set.seed(123)  # 设置随机数种子以确保结果可重现
# 自助法重抽样次数
n_bootstrap <- 1000
bootstrap_ginis <- numeric(n_bootstrap)  # 初始化保存基尼系数的向量

for (i in 1:n_bootstrap) {
  sampled_data <- Total1[sample(nrow(Total1), replace = TRUE), ]  # 带替换地随机抽样
  bootstrap_ginis[i] <- calculate_gini(sampled_data)  # 计算并保存基尼系数
}

# 计算95%置信区间
gini_ci <- quantile(bootstrap_ginis, probs = c(0.025, 0.975))
print(gini_ci)



#合在一起----
Total_combined_number <- rbind(Total, Total1)
A <- Total_combined_number %>% 
  ggplot(aes(x = new2, y = yDALYs, color = factor(year))) +  # 将年份转换为因子
  geom_point(aes(size = number)) +  # 设置空心圆形状和填充颜色
  geom_line(size=0.7) +  # 添加线条，设置线条颜色
  labs(x = "Cumulative fraction of population ranked by SDI", 
       y = "Cumulative fraction of mortality", 
       color = "year") +
  geom_segment(aes(x = 0, xend =1, y = 0, yend = 1), color = "#DEB348", size= 0.7) +  
  geom_linerange(aes(x = 1, ymin = 0, ymax = 1), color = "grey",size =0.7) +  
  geom_linerange(aes(xmin =0, xmax = 1, y = 0), color = "grey",size =0.7)+ 
  theme_bw() +  # 使用白色背景的主题
  scale_color_manual(values = c("#FF3333", "#33CCCC"))+  # 设置曲线颜色映射
  scale_size_continuous(
    limits = c(0, 800000000),
    breaks = seq(200000000, 800000000, by = 200000000),
    labels = function(x) paste0(x / 1000000),
    range = c(0.2, 3.4)  # 设置圆圈大小范围从最小到最大
  ) +  # 设置标签为以 "million" 为单位的文本
  guides(size = guide_legend(override.aes = list(fill = "white", shape = 1), title = "Population\n (million)"))+
  guides(color = guide_legend(override.aes = list(shape = 16, size = 1.5),title = "year"))+ # 设置图例项的填充色为白色，形状为圆圈
  theme(
    axis.line = element_line(color = "black",size = 0.5),
    panel.border = element_rect(color = "black", size = 0.5, fill = NA),  # 设置面板边框的颜色和大小
    panel.grid.major = element_line(size = 0.5),  
    panel.grid.minor = element_line(size = 0.5),  
    axis.title = element_text(size = 10,family = "serif",color = "black"),  # 设置坐标轴标题的字体大小和加粗
    axis.text = element_text(size = 10,family = "serif",color = "black"),  # 设置坐标轴标签的字体大小
    legend.text = element_text(size = 10,family = "serif",color = "black"),  # 设置图例文本的字体大小
    legend.title = element_text(size = 10,family = "serif",color = "black"))+  # 设置图例标题的字体大小
  theme(
    axis.text.x = element_text(margin = margin(t = 3, r = 0, b = 0, l = 0)),  # 调整X轴刻度与轴的距离
    axis.text.y = element_text(margin = margin(t = 0, r = 3, b = 0, l = 0)),  # 调整Y轴刻度与轴的距离
    axis.title.x = element_text(margin = margin(t = 5, r = 0, b = 0, l = 0)),  # 调整X轴标题与轴的距离
    axis.title.y = element_text(margin = margin(t = 0, r = 5, b = 0, l = 0)))  # 调整Y轴标题与轴的距离

print(A)

#pp1 +
#annotate("text", x = 0.1, y = 0.8, label = paste("Concentration Index (2019):", round(concentration_index_2019, 3))) +
#annotate("text", x = 0.1, y = 0.75, label = paste("95% CI (2019): [", round(confidence_interval_2019[1], 3), ", ", round(confidence_interval_2019[2], 3), "]")) +
#annotate("text", x = 0.1, y = 0.7, label = paste("Concentration Index (1990):", round(concentration_index_1990, 3))) +
#annotate("text", x = 0.1, y = 0.65, label = paste("95% CI (1990): [", round(confidence_interval_1990[1], 3), ", ", round(confidence_interval_1990[2], 3), "]"))

###结果输出
#ggsave("DALYs number-Neoplasms-both.PDF",width=8,height=5,units="in",dpi=300)

topptx(A,filename = "Mortality BC-Number.pptx",width = 8,#图形在宽度
       height = 5#图形在高度
)




########CC 
EC <- read.csv("疾病数据.csv")

#SII（斜度不公平指数）-------
#2019年-----
rate2019 <- subset(EC,EC$year ==2021&
                     EC$age == "All ages" &
                     #EC$sex == 'Female' &  
                     EC$metric == 'Rate' &
                     EC$cause == 'Cervical cancer' &
                     EC$measure == 'Deaths'
)[ , c(2, 8, 9,10)]

#合并SDI和人口学数据(Georgia重复）
SDII <- read.csv('SDI1990-2019modified.csv')
SDII <- plyr::rename(SDII,c(location="location_name"))
SDII <- subset(SDII,SDII$year==2021)
SDII <- SDII[,c(1,3)]

Population <- read.csv('population.CSV',header = T)
Population <- subset(Population, 
                     Population$sex_name == 'female' & 
                       Population$age_group_name == "All Ages" & 
                       Population$year_id == 2021)
Total_Population <- data.frame(location_name=rate2019$location,number=rep(0,times=204)) #创建一个数据框
for (i in 1:204){
  location_name_name <- as.character(Total_Population[i,1])
  a <- subset(Population, Population$location_name==location_name_name)  ##取对应地区的数据子集
  number <- sum(a$val)
  Total_Population[i,2] <- number
  
}
Total<- left_join(rate2019 ,Total_Population,by=c('location_name')) 
Total<- left_join(Total,SDII,by=c('location_name')) 
Total$SE <- (Total$upper-Total$lower)/(1.96*2) 
Total[,'year'] <-2021 
Total <- Total %>% arrange(SDI)
#write.csv(Total,'2019rate-BC.csv')   #自己去excel里面处理把SDI按照从小到大排序
#Total <- read.csv('2019rate-BC.csv',header = T)

# 然后，我们计算每个国家的人口占比
Total$cum_population <- Total$number / sum(Total$number)
#Total$Midpoint <- c(0, Total$cum_population[1:(nrow(Total)-1)]) / 2 + Total$cum_population / 2
#求累积人口占比
Total$new1 <- c(0, cumsum(Total$cum_population[1:(nrow(Total)-1)]))
Total$new2 <- cumsum(Total$cum_population)
#求累积人口占比的中点
Total$Midpoint <- (Total$new1 + Total$new2) / 2

#重复迭代加权线性回归
# install.packages("MASS")
library(MASS)
model <- rlm(val ~ Midpoint, data = Total)
# 斜率不等性指数就是回归系数
sii <- coef(model)["Midpoint"]
#计算95%置信区间
# 创建一个新的confint方法，适用于rlm对象
confint.rlm <- function (object, ...) {
  object$df.residual <- MASS:::summary.rlm(object)$df[2]
  confint.lm(object, ...)
}
# 使用新的方法计算置信区间
confint.rlm(model)

#1990年-----
rate1990 <- subset(EC,EC$year ==1990&
                     EC$age == "All ages" &
                     #EC$sex == 'Both' &  
                     EC$metric == 'Rate' &
                     EC$cause == 'Cervical cancer' &
                     EC$measure == 'Deaths'
)[ , c(2, 8, 9, 10)]

#合并SDI和人口学数据
SDII <- read.csv('SDI1990-2019modified.csv')
SDII <- plyr::rename(SDII,c(location="location_name"))
SDII <- subset(SDII,SDII$year==1990)
SDII <- SDII[,c(1,3)]
Population <- read.csv('population.CSV',header = T)
Population <- subset(Population, 
                     Population$sex_name == 'female' & 
                       Population$age_group_name == "All Ages" & 
                       Population$year_id == 1990)
Total_Population <- data.frame(location_name=rate1990$location_name,number=rep(0,times=204)) #创建一个数据框
for (i in 1:204){
  location_name_name <- as.character(Total_Population[i,1])
  a <- subset(Population, Population$location_name==location_name_name)  ##取对应地区的数据子集
  number <- sum(a$val)
  Total_Population[i,2] <- number
  
}
Total1<- left_join(rate1990 ,Total_Population,by=c('location_name')) 
Total1<- left_join(Total1,SDII,by=c('location_name')) 
Total1$SE <- (Total1$upper-Total1$lower)/(1.96*2) 
Total1[,'year'] <-1990
Total1 <- Total1 %>% arrange(SDI)
#write.csv(Total1,'1990rate-BC.csv')   #去excel里面处理，把SDI按照从小到大排序
#Total1 <- read.csv('1990rate-BC.csv',header = T)

# 然后，我们计算每个国家的人口占比
Total1$cum_population <- Total1$number / sum(Total1$number)
#Total1$Midpoint <- c(0, Total1$cum_population[1:(nrow(Total1)-1)]) / 2 + Total1$cum_population / 2
#求累积人口占比
Total1$new1 <- c(0, cumsum(Total1$cum_population[1:(nrow(Total1)-1)]))
Total1$new2 <- cumsum(Total1$cum_population)
#求累积人口占比的中点
Total1$Midpoint <- (Total1$new1 + Total1$new2) / 2

#重复迭代加权线性回归
model1 <- rlm(val ~ Midpoint, data = Total1)
# 斜率不等性指数就是回归系数
sii <- coef(model1)["Midpoint"]
#计算95%置信区间
# 创建一个新的confint方法，适用于rlm对象
confint.rlm <- function (object, ...) {
  object$df.residual <- MASS:::summary.rlm(object)$df[2]
  confint.lm(object, ...)
}
# 使用新的方法计算置信区间
confint.rlm(model1)


###画图,合在一起-----
Total_rate_combined <- rbind(Total, Total1)

# 按年份分组，并对每一组进行重复迭代加权线性回归
Total_rate_combined <- Total_rate_combined %>%
  group_by(year) %>%
  do({
    model <- rlm(val ~ Midpoint, data = .)
    data.frame(., pred = predict(model, newdata = .,interval = "confidence"))
  })

summary(model)


# 绘图
library(ggplot2)
library(dplyr)
A <- Total_rate_combined %>% 
  ggplot(aes(x = Midpoint, y = val, color = factor(year))) +  # 将年份转换为因子
  geom_point(aes(size = number)) +  # 设置空心圆形状和填充颜色
  geom_line(aes(y=pred.fit),size=0.7) +  # 添加线条，设置线条颜色
  geom_ribbon(data = subset(Total_rate_combined, year==1990),aes(ymin = pred.lwr, ymax = pred.upr), fill = "#c94741",color = NA, alpha = 0.2) +  # 添加预测的置信区间
  geom_ribbon(data = subset(Total_rate_combined, year==2021),aes(ymin = pred.lwr, ymax = pred.upr), fill = "#4593c3",color = NA,alpha = 0.2)+
  labs(x = "Relative rank by SDI", 
       y = "Crude mortality rate (per 100,000)", 
       color = "year") +
  theme_bw() +  # 使用白色背景的主题
  scale_color_manual(values = c("#FF3333", "#33CCCC"))+  # 设置曲线颜色映射
  geom_linerange(aes(xmin = 0, xmax = 1, y = 0.3116923), color = "#FF3333",lty = 3,size =0.7) +  
  geom_linerange(aes(xmin = 0, xmax = 1, y = 1.2722551), color = "#33CCCC",lty = 3,size =0.7)+
  scale_size_continuous(
    limits = c(0, 800000000),
    breaks = seq(200000000, 800000000, by = 200000000),
    labels = function(x) paste0(x / 1000000),
    range = c(0.2, 3.4)  # 设置圆圈大小范围从最小到最大
  ) +  # 设置标签为以 "million" 为单位的文本
  guides(color = guide_legend(override.aes = list(shape = 16, size = 1.5),title = "year"))+ # 设置图例项的填充色为白色，形状为圆圈
  guides(size = guide_legend(override.aes = list(fill = "white", shape = 1), title = "Population\n (million)"))+
  theme(
    axis.line = element_line(color = "black",size = 0.5),
    panel.border = element_rect(color = "black", size = 0.5, fill = NA),  # 设置面板边框的颜色和大小
    panel.grid.major = element_line(size = 0.5),  
    panel.grid.minor = element_line(size = 0.5),  
    axis.title = element_text(size = 10,family = "serif",color = "black"),  # 设置坐标轴标题的字体大小和加粗
    axis.text = element_text(size = 10,family = "serif",color = "black"),  # 设置坐标轴标签的字体大小
    legend.text = element_text(size = 10,family = "serif",color = "black"),  # 设置图例文本的字体大小
    legend.title = element_text(size = 10,family = "serif",color = "black"))+  # 设置图例标题的字体大小
  theme(
    axis.text.x = element_text(margin = margin(t = 3, r = 0, b = 0, l = 0)),  # 调整X轴刻度与轴的距离
    axis.text.y = element_text(margin = margin(t = 0, r = 3, b = 0, l = 0)),  # 调整Y轴刻度与轴的距离
    axis.title.x = element_text(margin = margin(t = 5, r = 0, b = 0, l = 0)),  # 调整X轴标题与轴的距离
    axis.title.y = element_text(margin = margin(t = 0, r = 5, b = 0, l = 0)))
#+scale_x_continuous(limits = c(0, 1.125),breaks = seq(0,1.00,by = 0.25))
#scale_y_continuous(limits = c(0, 20)) # 设置y轴刻度范围从0到10)  # 调整Y轴标题与轴的距离

print(A)

library(eoffice) #加载包，将图导出为PPTX
topptx(A,filename = "Mortality CC-rate.pptx",
       width =8, height = 5)#将生存曲线保存在ppt中


##集中指数画图-----Number
#2019年-----

number2019 <- subset(EC,EC$year ==2021&
                       EC$age == "All ages" &
                       EC$metric == 'Number' &
                       EC$cause == 'Cervical cancer' &
                       EC$measure == 'Deaths'
)[ , c(2, 8, 9, 10)]
#合并SDI和人口学数据
SDII <- read.csv('SDI1990-2019modified.csv')
SDII <- plyr::rename(SDII,c(location="location_name"))
SDII <- subset(SDII,SDII$year==2021)
SDII <- SDII[,c(1,3)]
Population <- read.csv('population.CSV',header = T)
Population <- subset(Population, 
                     Population$sex_name == 'female' & 
                       Population$age_group_name == "All Ages" & 
                       Population$year_id == 2021)
Total_Population <- data.frame(location_name=number2019$location_name,number=rep(0,times=204)) #创建一个数据框
for (i in 1:204){
  location_name_name <- as.character(Total_Population[i,1])
  a <- subset(Population, Population$location_name==location_name_name)  ##取对应地区的数据子集
  number <- sum(a$val)
  Total_Population[i,2] <- number
  
}
Total<- left_join(number2019 ,Total_Population,by=c('location_name')) 
Total<- left_join(Total,SDII,by=c('location_name')) 
Total$SE <- (Total$upper-Total$lower)/(1.96*2) 
Total[,'year'] <-2021
Total <- Total %>% arrange(SDI)
#write.csv(Total,'2019number-BC.csv')   #自己去excel里面处理把SDI按照从小到大排序


# 然后，我们计算每个国家的人口占比
Total$cum_population <- Total$number / sum(Total$number)
#Total$Midpoint <- c(0, Total$cum_population[1:(nrow(Total)-1)]) / 2 + Total$cum_population / 2

#求累积人口占比
Total$new1 <- c(0, cumsum(Total$cum_population[1:(nrow(Total)-1)]))
Total$new2 <- cumsum(Total$cum_population)
#求累积人口占比的中点
Total$Midpoint <- (Total$new1 + Total$new2) / 2

Total$cum_DALYs <- Total$val / sum(Total$val)
Total$yDALYs <- cumsum(Total$cum_DALYs)


# 假设 Total_combined_number 已经按照 new2 排序
# 计算洛伦兹曲线下的面积，使用梯形法则
lorenz_curve_area <- with(Total, sum(diff(new2) * (yDALYs[-length(yDALYs)] + yDALYs[-1])/2))

# 计算基尼系数
gini_coefficient <- 1 - 2 * lorenz_curve_area

# 打印基尼系数
print(gini_coefficient)

calculate_gini <- function(df) {
  # 确保数据按照累积人口占比排序
  df <- df[order(df$new2), ]
  # 计算洛伦兹曲线下的面积（梯形法则）
  lorenz_curve_area <- sum(diff(df$new2) * (df$yDALYs[-length(df$yDALYs)] + df$yDALYs[-1]) / 2)
  # 计算基尼系数
  gini_coefficient <- 1 - 2 * lorenz_curve_area
  return(gini_coefficient)
}
set.seed(123)  # 设置随机数种子以确保结果可重现
# 自助法重抽样次数
n_bootstrap <- 1000
bootstrap_ginis <- numeric(n_bootstrap)  # 初始化保存基尼系数的向量

for (i in 1:n_bootstrap) {
  sampled_data <- Total[sample(nrow(Total), replace = TRUE), ]  # 带替换地随机抽样
  bootstrap_ginis[i] <- calculate_gini(sampled_data)  # 计算并保存基尼系数
}

# 计算95%置信区间
gini_ci <- quantile(bootstrap_ginis, probs = c(0.025, 0.975))
print(gini_ci)


#1990年-----
number1990 <- subset(EC,EC$year ==1990&
                       EC$age == "All ages" &
                       EC$metric == 'Number' &
                       EC$cause == 'Cervical cancer' &
                       EC$measure == 'Deaths'
)[ , c(2, 8, 9, 10)]

#合并SDI和人口学数据
SDII <- read.csv('SDI1990-2019modified.csv')
SDII <- plyr::rename(SDII,c(location="location_name"))
SDII <- subset(SDII,SDII$year==1990)
SDII <- SDII[,c(1,3)]
Population <- read.csv('population.CSV',header = T)
Population <- subset(Population, 
                     Population$sex_name == 'female' & 
                       Population$age_group_name == "All Ages" & 
                       Population$year_id == 1990)
Total_Population <- data.frame(location_name=number1990$location_name,number=rep(0,times=204)) #创建一个数据框
for (i in 1:204){
  location_name_name <- as.character(Total_Population[i,1])
  a <- subset(Population, Population$location_name==location_name_name)  ##取对应地区的数据子集
  number <- sum(a$val)
  Total_Population[i,2] <- number
  
}
Total1<- left_join(number1990 ,Total_Population,by=c('location_name')) 
Total1<- left_join(Total1,SDII,by=c('location_name')) 
Total1$SE <- (Total1$upper-Total1$lower)/(1.96*2) 
Total1[,'year'] <-1990
Total1 <- Total1 %>% arrange(SDI)
#write.csv(Total1,'1990number-BC.csv')   #去excel里面处理，把SDI按照从小到大排序


# 然后，我们计算每个国家的人口占比
Total1$cum_population <- Total1$number / sum(Total1$number)
#Total$Midpoint <- c(0, Total$cum_population[1:(nrow(Total)-1)]) / 2 + Total$cum_population / 2

#求累积人口占比
Total1$new1 <- c(0, cumsum(Total1$cum_population[1:(nrow(Total1)-1)]))
Total1$new2 <- cumsum(Total1$cum_population)
#求累积人口占比的中点
Total1$Midpoint <- (Total1$new1 + Total1$new2) / 2

Total1$cum_DALYs <- Total1$val / sum(Total1$val)
Total1$yDALYs <- cumsum(Total1$cum_DALYs)
# 假设 Total_combined_number 已经按照 new2 排序
# 计算洛伦兹曲线下的面积，使用梯形法则
lorenz_curve_area <- with(Total1, sum(diff(new2) * (yDALYs[-length(yDALYs)] + yDALYs[-1])/2))

# 计算基尼系数
gini_coefficient <- 1 - 2 * lorenz_curve_area

# 打印基尼系数
print(gini_coefficient)

calculate_gini <- function(df) {
  # 确保数据按照累积人口占比排序
  df <- df[order(df$new2), ]
  # 计算洛伦兹曲线下的面积（梯形法则）
  lorenz_curve_area <- sum(diff(df$new2) * (df$yDALYs[-length(df$yDALYs)] + df$yDALYs[-1]) / 2)
  # 计算基尼系数
  gini_coefficient <- 1 - 2 * lorenz_curve_area
  return(gini_coefficient)
}
set.seed(123)  # 设置随机数种子以确保结果可重现
# 自助法重抽样次数
n_bootstrap <- 1000
bootstrap_ginis <- numeric(n_bootstrap)  # 初始化保存基尼系数的向量

for (i in 1:n_bootstrap) {
  sampled_data <- Total1[sample(nrow(Total1), replace = TRUE), ]  # 带替换地随机抽样
  bootstrap_ginis[i] <- calculate_gini(sampled_data)  # 计算并保存基尼系数
}

# 计算95%置信区间
gini_ci <- quantile(bootstrap_ginis, probs = c(0.025, 0.975))
print(gini_ci)



#合在一起----
Total_combined_number <- rbind(Total, Total1)
A <- Total_combined_number %>% 
  ggplot(aes(x = new2, y = yDALYs, color = factor(year))) +  # 将年份转换为因子
  geom_point(aes(size = number)) +  # 设置空心圆形状和填充颜色
  geom_line(size=0.7) +  # 添加线条，设置线条颜色
  labs(x = "Cumulative fraction of population ranked by SDI", 
       y = "Cumulative fraction of mortality", 
       color = "year") +
  geom_segment(aes(x = 0, xend =1, y = 0, yend = 1), color = "#DEB348", size= 0.7) +  
  geom_linerange(aes(x = 1, ymin = 0, ymax = 1), color = "grey",size =0.7) +  
  geom_linerange(aes(xmin =0, xmax = 1, y = 0), color = "grey",size =0.7)+ 
  theme_bw() +  # 使用白色背景的主题
  scale_color_manual(values = c("#FF3333", "#33CCCC"))+  # 设置曲线颜色映射
  scale_size_continuous(
    limits = c(0, 800000000),
    breaks = seq(200000000, 800000000, by = 200000000),
    labels = function(x) paste0(x / 1000000),
    range = c(0.2, 3.4)  # 设置圆圈大小范围从最小到最大
  ) +  # 设置标签为以 "million" 为单位的文本
  guides(size = guide_legend(override.aes = list(fill = "white", shape = 1), title = "Population\n (million)"))+
  guides(color = guide_legend(override.aes = list(shape = 16, size = 1.5),title = "year"))+ # 设置图例项的填充色为白色，形状为圆圈
  theme(
    axis.line = element_line(color = "black",size = 0.5),
    panel.border = element_rect(color = "black", size = 0.5, fill = NA),  # 设置面板边框的颜色和大小
    panel.grid.major = element_line(size = 0.5),  
    panel.grid.minor = element_line(size = 0.5),  
    axis.title = element_text(size = 10,family = "serif",color = "black"),  # 设置坐标轴标题的字体大小和加粗
    axis.text = element_text(size = 10,family = "serif",color = "black"),  # 设置坐标轴标签的字体大小
    legend.text = element_text(size = 10,family = "serif",color = "black"),  # 设置图例文本的字体大小
    legend.title = element_text(size = 10,family = "serif",color = "black"))+  # 设置图例标题的字体大小
  theme(
    axis.text.x = element_text(margin = margin(t = 3, r = 0, b = 0, l = 0)),  # 调整X轴刻度与轴的距离
    axis.text.y = element_text(margin = margin(t = 0, r = 3, b = 0, l = 0)),  # 调整Y轴刻度与轴的距离
    axis.title.x = element_text(margin = margin(t = 5, r = 0, b = 0, l = 0)),  # 调整X轴标题与轴的距离
    axis.title.y = element_text(margin = margin(t = 0, r = 5, b = 0, l = 0)))  # 调整Y轴标题与轴的距离

print(A)


###结果输出
#ggsave("DALYs number-Neoplasms-both.PDF",width=8,height=5,units="in",dpi=300)

topptx(A,filename = "Mortality number-CC.pptx",width = 8,#图形在宽度
       height = 5#图形在高度
)





################UC 
EC <- read.csv("疾病数据.csv")

#SII（斜度不公平指数）-------
#2019年-----
rate2019 <- subset(EC,EC$year ==2021&
                     EC$age == "All ages" &
                     #EC$sex == 'Female' &  
                     EC$metric == 'Rate' &
                     EC$cause == 'Uterine cancer' &
                     EC$measure == 'Deaths'
)[ , c(2, 8, 9,10)]

#合并SDI和人口学数据(Georgia重复）
SDII <- read.csv('SDI1990-2019modified.csv')
SDII <- plyr::rename(SDII,c(location="location_name"))
SDII <- subset(SDII,SDII$year==2021)
SDII <- SDII[,c(1,3)]

Population <- read.csv('population.CSV',header = T)
Population <- subset(Population, 
                     Population$sex_name == 'female' & 
                       Population$age_group_name == "All Ages" & 
                       Population$year_id == 2021)
Total_Population <- data.frame(location_name=rate2019$location,number=rep(0,times=204)) #创建一个数据框
for (i in 1:204){
  location_name_name <- as.character(Total_Population[i,1])
  a <- subset(Population, Population$location_name==location_name_name)  ##取对应地区的数据子集
  number <- sum(a$val)
  Total_Population[i,2] <- number
  
}
Total<- left_join(rate2019 ,Total_Population,by=c('location_name')) 
Total<- left_join(Total,SDII,by=c('location_name')) 
Total$SE <- (Total$upper-Total$lower)/(1.96*2) 
Total[,'year'] <-2021 
Total <- Total %>% arrange(SDI)
#write.csv(Total,'2019rate-BC.csv')   #自己去excel里面处理把SDI按照从小到大排序
#Total <- read.csv('2019rate-BC.csv',header = T)

# 然后，我们计算每个国家的人口占比
Total$cum_population <- Total$number / sum(Total$number)
#Total$Midpoint <- c(0, Total$cum_population[1:(nrow(Total)-1)]) / 2 + Total$cum_population / 2
#求累积人口占比
Total$new1 <- c(0, cumsum(Total$cum_population[1:(nrow(Total)-1)]))
Total$new2 <- cumsum(Total$cum_population)
#求累积人口占比的中点
Total$Midpoint <- (Total$new1 + Total$new2) / 2

#重复迭代加权线性回归
# install.packages("MASS")
library(MASS)
model <- rlm(val ~ Midpoint, data = Total)
# 斜率不等性指数就是回归系数
sii <- coef(model)["Midpoint"]
#计算95%置信区间
# 创建一个新的confint方法，适用于rlm对象
confint.rlm <- function (object, ...) {
  object$df.residual <- MASS:::summary.rlm(object)$df[2]
  confint.lm(object, ...)
}
# 使用新的方法计算置信区间
confint.rlm(model)

#1990年-----
rate1990 <- subset(EC,EC$year ==1990&
                     EC$age == "All ages" &
                     #EC$sex == 'Both' &  
                     EC$metric == 'Rate' &
                     EC$cause == 'Uterine cancer' &
                     EC$measure == 'Deaths'
)[ , c(2, 8, 9, 10)]

#合并SDI和人口学数据
SDII <- read.csv('SDI1990-2019modified.csv')
SDII <- plyr::rename(SDII,c(location="location_name"))
SDII <- subset(SDII,SDII$year==1990)
SDII <- SDII[,c(1,3)]
Population <- read.csv('population.CSV',header = T)
Population <- subset(Population, 
                     Population$sex_name == 'female' & 
                       Population$age_group_name == "All Ages" & 
                       Population$year_id == 1990)
Total_Population <- data.frame(location_name=rate1990$location_name,number=rep(0,times=204)) #创建一个数据框
for (i in 1:204){
  location_name_name <- as.character(Total_Population[i,1])
  a <- subset(Population, Population$location_name==location_name_name)  ##取对应地区的数据子集
  number <- sum(a$val)
  Total_Population[i,2] <- number
  
}
Total1<- left_join(rate1990 ,Total_Population,by=c('location_name')) 
Total1<- left_join(Total1,SDII,by=c('location_name')) 
Total1$SE <- (Total1$upper-Total1$lower)/(1.96*2) 
Total1[,'year'] <-1990
Total1 <- Total1 %>% arrange(SDI)
#write.csv(Total1,'1990rate-BC.csv')   #去excel里面处理，把SDI按照从小到大排序
#Total1 <- read.csv('1990rate-BC.csv',header = T)

# 然后，我们计算每个国家的人口占比
Total1$cum_population <- Total1$number / sum(Total1$number)
#Total1$Midpoint <- c(0, Total1$cum_population[1:(nrow(Total1)-1)]) / 2 + Total1$cum_population / 2
#求累积人口占比
Total1$new1 <- c(0, cumsum(Total1$cum_population[1:(nrow(Total1)-1)]))
Total1$new2 <- cumsum(Total1$cum_population)
#求累积人口占比的中点
Total1$Midpoint <- (Total1$new1 + Total1$new2) / 2

#重复迭代加权线性回归
model1 <- rlm(val ~ Midpoint, data = Total1)
# 斜率不等性指数就是回归系数
sii <- coef(model1)["Midpoint"]
#计算95%置信区间
# 创建一个新的confint方法，适用于rlm对象
confint.rlm <- function (object, ...) {
  object$df.residual <- MASS:::summary.rlm(object)$df[2]
  confint.lm(object, ...)
}
# 使用新的方法计算置信区间
confint.rlm(model1)


###画图,合在一起-----
Total_rate_combined <- rbind(Total, Total1)

# 按年份分组，并对每一组进行重复迭代加权线性回归
Total_rate_combined <- Total_rate_combined %>%
  group_by(year) %>%
  do({
    model <- rlm(val ~ Midpoint, data = .)
    data.frame(., pred = predict(model, newdata = .,interval = "confidence"))
  })

summary(model)


# 绘图
library(ggplot2)
library(dplyr)
A <- Total_rate_combined %>% 
  ggplot(aes(x = Midpoint, y = val, color = factor(year))) +  # 将年份转换为因子
  geom_point(aes(size = number)) +  # 设置空心圆形状和填充颜色
  geom_line(aes(y=pred.fit),size=0.7) +  # 添加线条，设置线条颜色
  geom_ribbon(data = subset(Total_rate_combined, year==1990),aes(ymin = pred.lwr, ymax = pred.upr), fill = "#c94741",color = NA, alpha = 0.2) +  # 添加预测的置信区间
  geom_ribbon(data = subset(Total_rate_combined, year==2021),aes(ymin = pred.lwr, ymax = pred.upr), fill = "#4593c3",color = NA,alpha = 0.2)+
  labs(x = "Relative rank by SDI", 
       y = "Crude mortality rate (per 100,000)", 
       color = "year") +
  theme_bw() +  # 使用白色背景的主题
  scale_color_manual(values = c("#FF3333", "#33CCCC"))+  # 设置曲线颜色映射
  geom_linerange(aes(xmin = 0, xmax = 1, y = 0.3116923), color = "#FF3333",lty = 3,size =0.7) +  
  geom_linerange(aes(xmin = 0, xmax = 1, y = 1.2722551), color = "#33CCCC",lty = 3,size =0.7)+
  scale_size_continuous(
    limits = c(0, 800000000),
    breaks = seq(200000000, 800000000, by = 200000000),
    labels = function(x) paste0(x / 1000000),
    range = c(0.2, 3.4)  # 设置圆圈大小范围从最小到最大
  ) +  # 设置标签为以 "million" 为单位的文本
  guides(color = guide_legend(override.aes = list(shape = 16, size = 1.5),title = "year"))+ # 设置图例项的填充色为白色，形状为圆圈
  guides(size = guide_legend(override.aes = list(fill = "white", shape = 1), title = "Population\n (million)"))+
  theme(
    axis.line = element_line(color = "black",size = 0.5),
    panel.border = element_rect(color = "black", size = 0.5, fill = NA),  # 设置面板边框的颜色和大小
    panel.grid.major = element_line(size = 0.5),  
    panel.grid.minor = element_line(size = 0.5),  
    axis.title = element_text(size = 10,family = "serif",color = "black"),  # 设置坐标轴标题的字体大小和加粗
    axis.text = element_text(size = 10,family = "serif",color = "black"),  # 设置坐标轴标签的字体大小
    legend.text = element_text(size = 10,family = "serif",color = "black"),  # 设置图例文本的字体大小
    legend.title = element_text(size = 10,family = "serif",color = "black"))+  # 设置图例标题的字体大小
  theme(
    axis.text.x = element_text(margin = margin(t = 3, r = 0, b = 0, l = 0)),  # 调整X轴刻度与轴的距离
    axis.text.y = element_text(margin = margin(t = 0, r = 3, b = 0, l = 0)),  # 调整Y轴刻度与轴的距离
    axis.title.x = element_text(margin = margin(t = 5, r = 0, b = 0, l = 0)),  # 调整X轴标题与轴的距离
    axis.title.y = element_text(margin = margin(t = 0, r = 5, b = 0, l = 0)))
#+scale_x_continuous(limits = c(0, 1.125),breaks = seq(0,1.00,by = 0.25))
#scale_y_continuous(limits = c(0, 20)) # 设置y轴刻度范围从0到10)  # 调整Y轴标题与轴的距离

print(A)

library(eoffice) #加载包，将图导出为PPTX
topptx(A,filename = "Mortality UC-rate.pptx",
       width =8, height = 5)#将生存曲线保存在ppt中


##集中指数画图-----Number
#2019年-----

number2019 <- subset(EC,EC$year ==2021&
                       EC$age == "All ages" &
                       EC$metric == 'Number' &
                       EC$cause == 'Uterine cancer' &
                       EC$measure == 'Deaths'
)[ , c(2, 8, 9, 10)]
#合并SDI和人口学数据
SDII <- read.csv('SDI1990-2019modified.csv')
SDII <- plyr::rename(SDII,c(location="location_name"))
SDII <- subset(SDII,SDII$year==2021)
SDII <- SDII[,c(1,3)]
Population <- read.csv('population.CSV',header = T)
Population <- subset(Population, 
                     Population$sex_name == 'female' & 
                       Population$age_group_name == "All Ages" & 
                       Population$year_id == 2021)
Total_Population <- data.frame(location_name=number2019$location_name,number=rep(0,times=204)) #创建一个数据框
for (i in 1:204){
  location_name_name <- as.character(Total_Population[i,1])
  a <- subset(Population, Population$location_name==location_name_name)  ##取对应地区的数据子集
  number <- sum(a$val)
  Total_Population[i,2] <- number
  
}
Total<- left_join(number2019 ,Total_Population,by=c('location_name')) 
Total<- left_join(Total,SDII,by=c('location_name')) 
Total$SE <- (Total$upper-Total$lower)/(1.96*2) 
Total[,'year'] <-2021
Total <- Total %>% arrange(SDI)
#write.csv(Total,'2019number-BC.csv')   #自己去excel里面处理把SDI按照从小到大排序


# 然后，我们计算每个国家的人口占比
Total$cum_population <- Total$number / sum(Total$number)
#Total$Midpoint <- c(0, Total$cum_population[1:(nrow(Total)-1)]) / 2 + Total$cum_population / 2

#求累积人口占比
Total$new1 <- c(0, cumsum(Total$cum_population[1:(nrow(Total)-1)]))
Total$new2 <- cumsum(Total$cum_population)
#求累积人口占比的中点
Total$Midpoint <- (Total$new1 + Total$new2) / 2

Total$cum_DALYs <- Total$val / sum(Total$val)
Total$yDALYs <- cumsum(Total$cum_DALYs)


# 假设 Total_combined_number 已经按照 new2 排序
# 计算洛伦兹曲线下的面积，使用梯形法则
lorenz_curve_area <- with(Total, sum(diff(new2) * (yDALYs[-length(yDALYs)] + yDALYs[-1])/2))

# 计算基尼系数
gini_coefficient <- 1 - 2 * lorenz_curve_area

# 打印基尼系数
print(gini_coefficient)

calculate_gini <- function(df) {
  # 确保数据按照累积人口占比排序
  df <- df[order(df$new2), ]
  # 计算洛伦兹曲线下的面积（梯形法则）
  lorenz_curve_area <- sum(diff(df$new2) * (df$yDALYs[-length(df$yDALYs)] + df$yDALYs[-1]) / 2)
  # 计算基尼系数
  gini_coefficient <- 1 - 2 * lorenz_curve_area
  return(gini_coefficient)
}
set.seed(123)  # 设置随机数种子以确保结果可重现
# 自助法重抽样次数
n_bootstrap <- 1000
bootstrap_ginis <- numeric(n_bootstrap)  # 初始化保存基尼系数的向量

for (i in 1:n_bootstrap) {
  sampled_data <- Total[sample(nrow(Total), replace = TRUE), ]  # 带替换地随机抽样
  bootstrap_ginis[i] <- calculate_gini(sampled_data)  # 计算并保存基尼系数
}

# 计算95%置信区间
gini_ci <- quantile(bootstrap_ginis, probs = c(0.025, 0.975))
print(gini_ci)


#1990年-----
number1990 <- subset(EC,EC$year ==1990&
                       EC$age == "All ages" &
                       EC$metric == 'Number' &
                       EC$cause == 'Uterine cancer' &
                       EC$measure == 'Deaths'
)[ , c(2, 8, 9, 10)]

#合并SDI和人口学数据
SDII <- read.csv('SDI1990-2019modified.csv')
SDII <- plyr::rename(SDII,c(location="location_name"))
SDII <- subset(SDII,SDII$year==1990)
SDII <- SDII[,c(1,3)]
Population <- read.csv('population.CSV',header = T)
Population <- subset(Population, 
                     Population$sex_name == 'female' & 
                       Population$age_group_name == "All Ages" & 
                       Population$year_id == 1990)
Total_Population <- data.frame(location_name=number1990$location_name,number=rep(0,times=204)) #创建一个数据框
for (i in 1:204){
  location_name_name <- as.character(Total_Population[i,1])
  a <- subset(Population, Population$location_name==location_name_name)  ##取对应地区的数据子集
  number <- sum(a$val)
  Total_Population[i,2] <- number
  
}
Total1<- left_join(number1990 ,Total_Population,by=c('location_name')) 
Total1<- left_join(Total1,SDII,by=c('location_name')) 
Total1$SE <- (Total1$upper-Total1$lower)/(1.96*2) 
Total1[,'year'] <-1990
Total1 <- Total1 %>% arrange(SDI)
#write.csv(Total1,'1990number-BC.csv')   #去excel里面处理，把SDI按照从小到大排序


# 然后，我们计算每个国家的人口占比
Total1$cum_population <- Total1$number / sum(Total1$number)
#Total$Midpoint <- c(0, Total$cum_population[1:(nrow(Total)-1)]) / 2 + Total$cum_population / 2

#求累积人口占比
Total1$new1 <- c(0, cumsum(Total1$cum_population[1:(nrow(Total1)-1)]))
Total1$new2 <- cumsum(Total1$cum_population)
#求累积人口占比的中点
Total1$Midpoint <- (Total1$new1 + Total1$new2) / 2

Total1$cum_DALYs <- Total1$val / sum(Total1$val)
Total1$yDALYs <- cumsum(Total1$cum_DALYs)
# 假设 Total_combined_number 已经按照 new2 排序
# 计算洛伦兹曲线下的面积，使用梯形法则
lorenz_curve_area <- with(Total1, sum(diff(new2) * (yDALYs[-length(yDALYs)] + yDALYs[-1])/2))

# 计算基尼系数
gini_coefficient <- 1 - 2 * lorenz_curve_area

# 打印基尼系数
print(gini_coefficient)

calculate_gini <- function(df) {
  # 确保数据按照累积人口占比排序
  df <- df[order(df$new2), ]
  # 计算洛伦兹曲线下的面积（梯形法则）
  lorenz_curve_area <- sum(diff(df$new2) * (df$yDALYs[-length(df$yDALYs)] + df$yDALYs[-1]) / 2)
  # 计算基尼系数
  gini_coefficient <- 1 - 2 * lorenz_curve_area
  return(gini_coefficient)
}
set.seed(123)  # 设置随机数种子以确保结果可重现
# 自助法重抽样次数
n_bootstrap <- 1000
bootstrap_ginis <- numeric(n_bootstrap)  # 初始化保存基尼系数的向量

for (i in 1:n_bootstrap) {
  sampled_data <- Total1[sample(nrow(Total1), replace = TRUE), ]  # 带替换地随机抽样
  bootstrap_ginis[i] <- calculate_gini(sampled_data)  # 计算并保存基尼系数
}

# 计算95%置信区间
gini_ci <- quantile(bootstrap_ginis, probs = c(0.025, 0.975))
print(gini_ci)



#合在一起----
Total_combined_number <- rbind(Total, Total1)
A <- Total_combined_number %>% 
  ggplot(aes(x = new2, y = yDALYs, color = factor(year))) +  # 将年份转换为因子
  geom_point(aes(size = number)) +  # 设置空心圆形状和填充颜色
  geom_line(size=0.7) +  # 添加线条，设置线条颜色
  labs(x = "Cumulative fraction of population ranked by SDI", 
       y = "Cumulative fraction of mortality", 
       color = "year") +
  geom_segment(aes(x = 0, xend =1, y = 0, yend = 1), color = "#DEB348", size= 0.7) +  
  geom_linerange(aes(x = 1, ymin = 0, ymax = 1), color = "grey",size =0.7) +  
  geom_linerange(aes(xmin =0, xmax = 1, y = 0), color = "grey",size =0.7)+ 
  theme_bw() +  # 使用白色背景的主题
  scale_color_manual(values = c("#FF3333", "#33CCCC"))+  # 设置曲线颜色映射
  scale_size_continuous(
    limits = c(0, 800000000),
    breaks = seq(200000000, 800000000, by = 200000000),
    labels = function(x) paste0(x / 1000000),
    range = c(0.2, 3.4)  # 设置圆圈大小范围从最小到最大
  ) +  # 设置标签为以 "million" 为单位的文本
  guides(size = guide_legend(override.aes = list(fill = "white", shape = 1), title = "Population\n (million)"))+
  guides(color = guide_legend(override.aes = list(shape = 16, size = 1.5),title = "year"))+ # 设置图例项的填充色为白色，形状为圆圈
  theme(
    axis.line = element_line(color = "black",size = 0.5),
    panel.border = element_rect(color = "black", size = 0.5, fill = NA),  # 设置面板边框的颜色和大小
    panel.grid.major = element_line(size = 0.5),  
    panel.grid.minor = element_line(size = 0.5),  
    axis.title = element_text(size = 10,family = "serif",color = "black"),  # 设置坐标轴标题的字体大小和加粗
    axis.text = element_text(size = 10,family = "serif",color = "black"),  # 设置坐标轴标签的字体大小
    legend.text = element_text(size = 10,family = "serif",color = "black"),  # 设置图例文本的字体大小
    legend.title = element_text(size = 10,family = "serif",color = "black"))+  # 设置图例标题的字体大小
  theme(
    axis.text.x = element_text(margin = margin(t = 3, r = 0, b = 0, l = 0)),  # 调整X轴刻度与轴的距离
    axis.text.y = element_text(margin = margin(t = 0, r = 3, b = 0, l = 0)),  # 调整Y轴刻度与轴的距离
    axis.title.x = element_text(margin = margin(t = 5, r = 0, b = 0, l = 0)),  # 调整X轴标题与轴的距离
    axis.title.y = element_text(margin = margin(t = 0, r = 5, b = 0, l = 0)))  # 调整Y轴标题与轴的距离

print(A)


###结果输出
#ggsave("DALYs number-Neoplasms-both.PDF",width=8,height=5,units="in",dpi=300)

topptx(A,filename = "Mortality number-UC.pptx",width = 8,#图形在宽度
       height = 5#图形在高度
)





########OC 
EC <- read.csv("疾病数据.csv")

#SII（斜度不公平指数）-------
#2019年-----
rate2019 <- subset(EC,EC$year ==2021&
                     EC$age == "All ages" &
                     #EC$sex == 'Female' &  
                     EC$metric == 'Rate' &
                     EC$cause == 'Ovarian cancer' &
                     EC$measure == 'Deaths'
)[ , c(2, 8, 9,10)]

#合并SDI和人口学数据(Georgia重复）
SDII <- read.csv('SDI1990-2019modified.csv')
SDII <- plyr::rename(SDII,c(location="location_name"))
SDII <- subset(SDII,SDII$year==2021)
SDII <- SDII[,c(1,3)]

Population <- read.csv('population.CSV',header = T)
Population <- subset(Population, 
                     Population$sex_name == 'female' & 
                       Population$age_group_name == "All Ages" & 
                       Population$year_id == 2021)
Total_Population <- data.frame(location_name=rate2019$location,number=rep(0,times=204)) #创建一个数据框
for (i in 1:204){
  location_name_name <- as.character(Total_Population[i,1])
  a <- subset(Population, Population$location_name==location_name_name)  ##取对应地区的数据子集
  number <- sum(a$val)
  Total_Population[i,2] <- number
  
}
Total<- left_join(rate2019 ,Total_Population,by=c('location_name')) 
Total<- left_join(Total,SDII,by=c('location_name')) 
Total$SE <- (Total$upper-Total$lower)/(1.96*2) 
Total[,'year'] <-2021 
Total <- Total %>% arrange(SDI)
#write.csv(Total,'2019rate-BC.csv')   #自己去excel里面处理把SDI按照从小到大排序
#Total <- read.csv('2019rate-BC.csv',header = T)

# 然后，我们计算每个国家的人口占比
Total$cum_population <- Total$number / sum(Total$number)
#Total$Midpoint <- c(0, Total$cum_population[1:(nrow(Total)-1)]) / 2 + Total$cum_population / 2
#求累积人口占比
Total$new1 <- c(0, cumsum(Total$cum_population[1:(nrow(Total)-1)]))
Total$new2 <- cumsum(Total$cum_population)
#求累积人口占比的中点
Total$Midpoint <- (Total$new1 + Total$new2) / 2

#重复迭代加权线性回归
# install.packages("MASS")
library(MASS)
model <- rlm(val ~ Midpoint, data = Total)
# 斜率不等性指数就是回归系数
sii <- coef(model)["Midpoint"]
#计算95%置信区间
# 创建一个新的confint方法，适用于rlm对象
confint.rlm <- function (object, ...) {
  object$df.residual <- MASS:::summary.rlm(object)$df[2]
  confint.lm(object, ...)
}
# 使用新的方法计算置信区间
confint.rlm(model)

#1990年-----
rate1990 <- subset(EC,EC$year ==1990&
                     EC$age == "All ages" &
                     #EC$sex == 'Both' &  
                     EC$metric == 'Rate' &
                     EC$cause == 'Ovarian cancer' &
                     EC$measure == 'Deaths'
)[ , c(2, 8, 9, 10)]

#合并SDI和人口学数据
SDII <- read.csv('SDI1990-2019modified.csv')
SDII <- plyr::rename(SDII,c(location="location_name"))
SDII <- subset(SDII,SDII$year==1990)
SDII <- SDII[,c(1,3)]
Population <- read.csv('population.CSV',header = T)
Population <- subset(Population, 
                     Population$sex_name == 'female' & 
                       Population$age_group_name == "All Ages" & 
                       Population$year_id == 1990)
Total_Population <- data.frame(location_name=rate1990$location_name,number=rep(0,times=204)) #创建一个数据框
for (i in 1:204){
  location_name_name <- as.character(Total_Population[i,1])
  a <- subset(Population, Population$location_name==location_name_name)  ##取对应地区的数据子集
  number <- sum(a$val)
  Total_Population[i,2] <- number
  
}
Total1<- left_join(rate1990 ,Total_Population,by=c('location_name')) 
Total1<- left_join(Total1,SDII,by=c('location_name')) 
Total1$SE <- (Total1$upper-Total1$lower)/(1.96*2) 
Total1[,'year'] <-1990
Total1 <- Total1 %>% arrange(SDI)
#write.csv(Total1,'1990rate-BC.csv')   #去excel里面处理，把SDI按照从小到大排序
#Total1 <- read.csv('1990rate-BC.csv',header = T)

# 然后，我们计算每个国家的人口占比
Total1$cum_population <- Total1$number / sum(Total1$number)
#Total1$Midpoint <- c(0, Total1$cum_population[1:(nrow(Total1)-1)]) / 2 + Total1$cum_population / 2
#求累积人口占比
Total1$new1 <- c(0, cumsum(Total1$cum_population[1:(nrow(Total1)-1)]))
Total1$new2 <- cumsum(Total1$cum_population)
#求累积人口占比的中点
Total1$Midpoint <- (Total1$new1 + Total1$new2) / 2

#重复迭代加权线性回归
model1 <- rlm(val ~ Midpoint, data = Total1)
# 斜率不等性指数就是回归系数
sii <- coef(model1)["Midpoint"]
#计算95%置信区间
# 创建一个新的confint方法，适用于rlm对象
confint.rlm <- function (object, ...) {
  object$df.residual <- MASS:::summary.rlm(object)$df[2]
  confint.lm(object, ...)
}
# 使用新的方法计算置信区间
confint.rlm(model1)


###画图,合在一起-----
Total_rate_combined <- rbind(Total, Total1)

# 按年份分组，并对每一组进行重复迭代加权线性回归
Total_rate_combined <- Total_rate_combined %>%
  group_by(year) %>%
  do({
    model <- rlm(val ~ Midpoint, data = .)
    data.frame(., pred = predict(model, newdata = .,interval = "confidence"))
  })

summary(model)


# 绘图
library(ggplot2)
library(dplyr)
A <- Total_rate_combined %>% 
  ggplot(aes(x = Midpoint, y = val, color = factor(year))) +  # 将年份转换为因子
  geom_point(aes(size = number)) +  # 设置空心圆形状和填充颜色
  geom_line(aes(y=pred.fit),size=0.7) +  # 添加线条，设置线条颜色
  geom_ribbon(data = subset(Total_rate_combined, year==1990),aes(ymin = pred.lwr, ymax = pred.upr), fill = "#c94741",color = NA, alpha = 0.2) +  # 添加预测的置信区间
  geom_ribbon(data = subset(Total_rate_combined, year==2021),aes(ymin = pred.lwr, ymax = pred.upr), fill = "#4593c3",color = NA,alpha = 0.2)+
  labs(x = "Relative rank by SDI", 
       y = "Crude mortality rate (per 100,000)", 
       color = "year") +
  theme_bw() +  # 使用白色背景的主题
  scale_color_manual(values = c("#FF3333", "#33CCCC"))+  # 设置曲线颜色映射
  geom_linerange(aes(xmin = 0, xmax = 1, y = 0.3116923), color = "#FF3333",lty = 3,size =0.7) +  
  geom_linerange(aes(xmin = 0, xmax = 1, y = 1.2722551), color = "#33CCCC",lty = 3,size =0.7)+
  scale_size_continuous(
    limits = c(0, 800000000),
    breaks = seq(200000000, 800000000, by = 200000000),
    labels = function(x) paste0(x / 1000000),
    range = c(0.2, 3.4)  # 设置圆圈大小范围从最小到最大
  ) +  # 设置标签为以 "million" 为单位的文本
  guides(color = guide_legend(override.aes = list(shape = 16, size = 1.5),title = "year"))+ # 设置图例项的填充色为白色，形状为圆圈
  guides(size = guide_legend(override.aes = list(fill = "white", shape = 1), title = "Population\n (million)"))+
  theme(
    axis.line = element_line(color = "black",size = 0.5),
    panel.border = element_rect(color = "black", size = 0.5, fill = NA),  # 设置面板边框的颜色和大小
    panel.grid.major = element_line(size = 0.5),  
    panel.grid.minor = element_line(size = 0.5),  
    axis.title = element_text(size = 10,family = "serif",color = "black"),  # 设置坐标轴标题的字体大小和加粗
    axis.text = element_text(size = 10,family = "serif",color = "black"),  # 设置坐标轴标签的字体大小
    legend.text = element_text(size = 10,family = "serif",color = "black"),  # 设置图例文本的字体大小
    legend.title = element_text(size = 10,family = "serif",color = "black"))+  # 设置图例标题的字体大小
  theme(
    axis.text.x = element_text(margin = margin(t = 3, r = 0, b = 0, l = 0)),  # 调整X轴刻度与轴的距离
    axis.text.y = element_text(margin = margin(t = 0, r = 3, b = 0, l = 0)),  # 调整Y轴刻度与轴的距离
    axis.title.x = element_text(margin = margin(t = 5, r = 0, b = 0, l = 0)),  # 调整X轴标题与轴的距离
    axis.title.y = element_text(margin = margin(t = 0, r = 5, b = 0, l = 0)))
#+scale_x_continuous(limits = c(0, 1.125),breaks = seq(0,1.00,by = 0.25))
#scale_y_continuous(limits = c(0, 20)) # 设置y轴刻度范围从0到10)  # 调整Y轴标题与轴的距离

print(A)

library(eoffice) #加载包，将图导出为PPTX
topptx(A,filename = "Mortality OC-rate.pptx",
       width =8, height = 5)#将生存曲线保存在ppt中


##集中指数画图-----Number
#2019年-----

number2019 <- subset(EC,EC$year ==2021&
                       EC$age == "All ages" &
                       EC$metric == 'Number' &
                       EC$cause == 'Ovarian cancer' &
                       EC$measure == 'Deaths'
)[ , c(2, 8, 9, 10)]
#合并SDI和人口学数据
SDII <- read.csv('SDI1990-2019modified.csv')
SDII <- plyr::rename(SDII,c(location="location_name"))
SDII <- subset(SDII,SDII$year==2021)
SDII <- SDII[,c(1,3)]
Population <- read.csv('population.CSV',header = T)
Population <- subset(Population, 
                     Population$sex_name == 'female' & 
                       Population$age_group_name == "All Ages" & 
                       Population$year_id == 2021)
Total_Population <- data.frame(location_name=number2019$location_name,number=rep(0,times=204)) #创建一个数据框
for (i in 1:204){
  location_name_name <- as.character(Total_Population[i,1])
  a <- subset(Population, Population$location_name==location_name_name)  ##取对应地区的数据子集
  number <- sum(a$val)
  Total_Population[i,2] <- number
  
}
Total<- left_join(number2019 ,Total_Population,by=c('location_name')) 
Total<- left_join(Total,SDII,by=c('location_name')) 
Total$SE <- (Total$upper-Total$lower)/(1.96*2) 
Total[,'year'] <-2021
Total <- Total %>% arrange(SDI)
#write.csv(Total,'2019number-BC.csv')   #自己去excel里面处理把SDI按照从小到大排序


# 然后，我们计算每个国家的人口占比
Total$cum_population <- Total$number / sum(Total$number)
#Total$Midpoint <- c(0, Total$cum_population[1:(nrow(Total)-1)]) / 2 + Total$cum_population / 2

#求累积人口占比
Total$new1 <- c(0, cumsum(Total$cum_population[1:(nrow(Total)-1)]))
Total$new2 <- cumsum(Total$cum_population)
#求累积人口占比的中点
Total$Midpoint <- (Total$new1 + Total$new2) / 2

Total$cum_DALYs <- Total$val / sum(Total$val)
Total$yDALYs <- cumsum(Total$cum_DALYs)


# 假设 Total_combined_number 已经按照 new2 排序
# 计算洛伦兹曲线下的面积，使用梯形法则
lorenz_curve_area <- with(Total, sum(diff(new2) * (yDALYs[-length(yDALYs)] + yDALYs[-1])/2))

# 计算基尼系数
gini_coefficient <- 1 - 2 * lorenz_curve_area

# 打印基尼系数
print(gini_coefficient)

calculate_gini <- function(df) {
  # 确保数据按照累积人口占比排序
  df <- df[order(df$new2), ]
  # 计算洛伦兹曲线下的面积（梯形法则）
  lorenz_curve_area <- sum(diff(df$new2) * (df$yDALYs[-length(df$yDALYs)] + df$yDALYs[-1]) / 2)
  # 计算基尼系数
  gini_coefficient <- 1 - 2 * lorenz_curve_area
  return(gini_coefficient)
}
set.seed(123)  # 设置随机数种子以确保结果可重现
# 自助法重抽样次数
n_bootstrap <- 1000
bootstrap_ginis <- numeric(n_bootstrap)  # 初始化保存基尼系数的向量

for (i in 1:n_bootstrap) {
  sampled_data <- Total[sample(nrow(Total), replace = TRUE), ]  # 带替换地随机抽样
  bootstrap_ginis[i] <- calculate_gini(sampled_data)  # 计算并保存基尼系数
}

# 计算95%置信区间
gini_ci <- quantile(bootstrap_ginis, probs = c(0.025, 0.975))
print(gini_ci)


#1990年-----
number1990 <- subset(EC,EC$year ==1990&
                       EC$age == "All ages" &
                       EC$metric == 'Number' &
                       EC$cause == 'Ovarian cancer' &
                       EC$measure == 'Deaths'
)[ , c(2, 8, 9, 10)]

#合并SDI和人口学数据
SDII <- read.csv('SDI1990-2019modified.csv')
SDII <- plyr::rename(SDII,c(location="location_name"))
SDII <- subset(SDII,SDII$year==1990)
SDII <- SDII[,c(1,3)]
Population <- read.csv('population.CSV',header = T)
Population <- subset(Population, 
                     Population$sex_name == 'female' & 
                       Population$age_group_name == "All Ages" & 
                       Population$year_id == 1990)
Total_Population <- data.frame(location_name=number1990$location_name,number=rep(0,times=204)) #创建一个数据框
for (i in 1:204){
  location_name_name <- as.character(Total_Population[i,1])
  a <- subset(Population, Population$location_name==location_name_name)  ##取对应地区的数据子集
  number <- sum(a$val)
  Total_Population[i,2] <- number
  
}
Total1<- left_join(number1990 ,Total_Population,by=c('location_name')) 
Total1<- left_join(Total1,SDII,by=c('location_name')) 
Total1$SE <- (Total1$upper-Total1$lower)/(1.96*2) 
Total1[,'year'] <-1990
Total1 <- Total1 %>% arrange(SDI)
#write.csv(Total1,'1990number-BC.csv')   #去excel里面处理，把SDI按照从小到大排序


# 然后，我们计算每个国家的人口占比
Total1$cum_population <- Total1$number / sum(Total1$number)
#Total$Midpoint <- c(0, Total$cum_population[1:(nrow(Total)-1)]) / 2 + Total$cum_population / 2

#求累积人口占比
Total1$new1 <- c(0, cumsum(Total1$cum_population[1:(nrow(Total1)-1)]))
Total1$new2 <- cumsum(Total1$cum_population)
#求累积人口占比的中点
Total1$Midpoint <- (Total1$new1 + Total1$new2) / 2

Total1$cum_DALYs <- Total1$val / sum(Total1$val)
Total1$yDALYs <- cumsum(Total1$cum_DALYs)
# 假设 Total_combined_number 已经按照 new2 排序
# 计算洛伦兹曲线下的面积，使用梯形法则
lorenz_curve_area <- with(Total1, sum(diff(new2) * (yDALYs[-length(yDALYs)] + yDALYs[-1])/2))

# 计算基尼系数
gini_coefficient <- 1 - 2 * lorenz_curve_area

# 打印基尼系数
print(gini_coefficient)

calculate_gini <- function(df) {
  # 确保数据按照累积人口占比排序
  df <- df[order(df$new2), ]
  # 计算洛伦兹曲线下的面积（梯形法则）
  lorenz_curve_area <- sum(diff(df$new2) * (df$yDALYs[-length(df$yDALYs)] + df$yDALYs[-1]) / 2)
  # 计算基尼系数
  gini_coefficient <- 1 - 2 * lorenz_curve_area
  return(gini_coefficient)
}
set.seed(123)  # 设置随机数种子以确保结果可重现
# 自助法重抽样次数
n_bootstrap <- 1000
bootstrap_ginis <- numeric(n_bootstrap)  # 初始化保存基尼系数的向量

for (i in 1:n_bootstrap) {
  sampled_data <- Total1[sample(nrow(Total1), replace = TRUE), ]  # 带替换地随机抽样
  bootstrap_ginis[i] <- calculate_gini(sampled_data)  # 计算并保存基尼系数
}

# 计算95%置信区间
gini_ci <- quantile(bootstrap_ginis, probs = c(0.025, 0.975))
print(gini_ci)



#合在一起----
Total_combined_number <- rbind(Total, Total1)
A <- Total_combined_number %>% 
  ggplot(aes(x = new2, y = yDALYs, color = factor(year))) +  # 将年份转换为因子
  geom_point(aes(size = number)) +  # 设置空心圆形状和填充颜色
  geom_line(size=0.7) +  # 添加线条，设置线条颜色
  labs(x = "Cumulative fraction of population ranked by SDI", 
       y = "Cumulative fraction of mortality", 
       color = "year") +
  geom_segment(aes(x = 0, xend =1, y = 0, yend = 1), color = "#DEB348", size= 0.7) +  
  geom_linerange(aes(x = 1, ymin = 0, ymax = 1), color = "grey",size =0.7) +  
  geom_linerange(aes(xmin =0, xmax = 1, y = 0), color = "grey",size =0.7)+ 
  theme_bw() +  # 使用白色背景的主题
  scale_color_manual(values = c("#FF3333", "#33CCCC"))+  # 设置曲线颜色映射
  scale_size_continuous(
    limits = c(0, 800000000),
    breaks = seq(200000000, 800000000, by = 200000000),
    labels = function(x) paste0(x / 1000000),
    range = c(0.2, 3.4)  # 设置圆圈大小范围从最小到最大
  ) +  # 设置标签为以 "million" 为单位的文本
  guides(size = guide_legend(override.aes = list(fill = "white", shape = 1), title = "Population\n (million)"))+
  guides(color = guide_legend(override.aes = list(shape = 16, size = 1.5),title = "year"))+ # 设置图例项的填充色为白色，形状为圆圈
  theme(
    axis.line = element_line(color = "black",size = 0.5),
    panel.border = element_rect(color = "black", size = 0.5, fill = NA),  # 设置面板边框的颜色和大小
    panel.grid.major = element_line(size = 0.5),  
    panel.grid.minor = element_line(size = 0.5),  
    axis.title = element_text(size = 10,family = "serif",color = "black"),  # 设置坐标轴标题的字体大小和加粗
    axis.text = element_text(size = 10,family = "serif",color = "black"),  # 设置坐标轴标签的字体大小
    legend.text = element_text(size = 10,family = "serif",color = "black"),  # 设置图例文本的字体大小
    legend.title = element_text(size = 10,family = "serif",color = "black"))+  # 设置图例标题的字体大小
  theme(
    axis.text.x = element_text(margin = margin(t = 3, r = 0, b = 0, l = 0)),  # 调整X轴刻度与轴的距离
    axis.text.y = element_text(margin = margin(t = 0, r = 3, b = 0, l = 0)),  # 调整Y轴刻度与轴的距离
    axis.title.x = element_text(margin = margin(t = 5, r = 0, b = 0, l = 0)),  # 调整X轴标题与轴的距离
    axis.title.y = element_text(margin = margin(t = 0, r = 5, b = 0, l = 0)))  # 调整Y轴标题与轴的距离

print(A)


###结果输出
#ggsave("DALYs number-Neoplasms-both.PDF",width=8,height=5,units="in",dpi=300)

topptx(A,filename = "Mortality number-OC.pptx",width = 8,#图形在宽度
       height = 5#图形在高度
)



